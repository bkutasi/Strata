# Assumptions and supported fixture contract

## Established input

The user supplied the original final-partial-follower condition. The v3 `parameterEnd` now returns the closer index for final empty/partial followers, and -2 for non-final partial followers. Complete follower prefixes retain their existing boundary behavior. Direct `parseToolCall` remains lenient; streamed framing still requires full function and tool-call closers. This does not establish all parser parity.

## Synthetic prompts and tool choices

- No model template is used. Text-only requests retain the legacy JSON message prompt. Tool requests use a `strata-byte-tools-v1` JSON object with `not_a_model_template: true`, normalized turns, tools, choice and `forced_prefix`.
- Tools are declarations only. The server does not execute tools. Clients supply results for replay.
- `auto` (or omitted) allows zero or more declared calls. `none` rejects recognized tool calls. OpenAI `required` / Anthropic `any` requires at least one call. A named choice requires calls to that name. Unknown or malformed HTTP choices are rejected, not silently treated as auto.
- Forced/required fixture scripts must contain the continuation after the prefix recorded in the prompt. A single required/named tool pre-fills `<tool_call>
<function=NAME>`. Multiple required tools pre-fill `<tool_call>
<function=`. The server feeds that prefix into its parser; it is not counted as generated output. This is not grammar-constrained inference. A full envelope in a forced continuation is not silently repaired.
- Forced calls disable the initial reasoning state for that request. Prefix whitespace and this interaction remain fixture assumptions.
- OpenAI supported choices: strings auto/none/required; named function object with nested function.name or direct name. Anthropic supported choices: objects with type auto/none/any/tool, and name for tool only. Other fields (including parallel-control flags) are rejected.

## Definitions, schema and history subset

- 1..64 definitions when tools is present. Empty/null tools remains rejected, preserving the old negative case. Names match `[A-Za-z0-9_.-]{1,64}` and must be unique.
- OpenAI function definitions require type:function and function:{name, parameters, optional description}. Anthropic definitions require name, input_schema and optional description. Root schema must explicitly have type:object.
- Supported schema keywords: type, description, properties, required, boolean additionalProperties, items and enum. Supported single types: object/array/string/number/integer/boolean/null. Other keywords, unions, references and strict flags are rejected. This is NOT full JSON Schema.
- Integer validation is lexical: 1 is accepted, 1.0 and 1e0 are rejected for integer schemas. Enum equality uses serialized JSON literals, so numeric spellings are not normalized. Numbers remain json.Number, including large integers. Nonstandard NaN/Infinity is not supported.
- Declared XML string parameters remain strings; other XML values attempt JSON decoding. JSON calls preserve JSON types and are then validated against the supported schema subset.
- Tool results must match unique earlier assistant call IDs. All pending calls must be resolved before another ordinary message and before the end of the request. Results may arrive in a different ID order. Duplicate/orphan results, duplicate call IDs, wrong roles and unresolved calls are rejected.
- History calls must be declared by the current tools list and satisfy its current schema. Cross-request persistence is not provided. Clients replay the transcript explicitly.
- OpenAI history supports string text, assistant tool_calls with string JSON arguments, null/omitted assistant content when calls exist, and tool messages with string results.
- Anthropic history supports text, assistant tool_use with object input, and user tool_result with string content and optional boolean is_error. Rich result blocks, thinking/signature replay and images are unsupported. Legacy string system-role messages remain accepted as a fixture compatibility behavior.
- Duplicate JSON object keys retain standard Go last-key behavior, as before. Full Unicode/surrogate and Python numeric semantics are not asserted.

## Output commit and streaming

- Tool-aware requests buffer/coalesce all output events until engine DONE, complete UTF-8/parsing, schema checks and choice checks succeed. No tool call is published if a later call is malformed, the engine fails, cancellation occurs before commit, or output ends with length after any call. This trades first-content latency for an auditable transaction boundary.
- Text-only requests keep the prior live text streaming behavior. The initial SSE role/message-start frame and keepalives may precede a tool transaction failure; they are not successful calls.
- OpenAI streams use tool_calls deltas with call index, generated ID, name and a complete serialized arguments string, then finish_reason:tool_calls and [DONE]. Anthropic streams use separate tool_use block start, input_json_delta with a complete JSON payload, block stop, message_delta stop_reason:tool_use and message_stop. Argument payloads are not token-by-token deltas.
- IDs are generated once per call and preserved through that response's events. OpenAI uses call_ IDs; Anthropic uses toolu_ IDs. Replayed IDs are retained, and new IDs avoid the replay set. Anthropic message IDs now use msg_; text-only v2 used chatcmpl_ for both APIs.
- API event order is an explicit fixture contract, not exact upstream event parity. Errors after SSE starts are terminal error frames without a successful finish marker. Network writes are not atomic: cancellation/disconnect during publication can leave a partial stream, which clients must not treat as complete without its terminal success marker.
- Schema depth is bounded to 16; output call count is bounded to 64; tool transaction text is bounded to 1 MiB, and generated byte count remains bounded by the request/context. These are not constant-RSS guarantees.

## Still missing

Quoted/fenced marker disambiguation outside explicit JSON call envelopes, aliases, recovery, DSML, full reasoning semantics, incremental argument deltas, Responses, model tokenizers/templates, actual model serving, vision/MCP/images, sessions/replicas/split, management/config parity and upstream CLI/desktop/packaging integration remain missing. Browser UI remains excluded.

Production model mode remains unavailable. The bridge requires fixture-byte-v1 before GEN and accepts only byte IDs. Python remains the standalone launcher's default. Engine direct-child lifecycle, FIFO, auth, Host/Origin checks and loopback binding are unchanged from v2. No process-tree/owner-loss/Windows-job guarantee is added. No production memory target is measured or claimed.

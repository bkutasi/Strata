"""Exercise an already-built isolated Go fixture process and measure ONLY its PID.
This does not certify production parity or real-model memory usage.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import http.client
import json
import os
from pathlib import Path
import platform
import selectors
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parent


def memory(pid):
    status = Path(f'/proc/{pid}/status').read_text()
    result = {}
    for line in status.splitlines():
        if line.startswith(('VmRSS:', 'VmHWM:')):
            key, value, unit = line.split()
            if unit != 'kB':
                raise RuntimeError('unexpected procfs memory unit')
            result[key[:-1] + '_KiB'] = int(value)
    for line in Path(f'/proc/{pid}/smaps_rollup').read_text().splitlines():
        if line.startswith('Pss:'):
            result['PSS_KiB'] = int(line.split()[1])
    return result


def request(address, path, payload=None, headers=None, chunked=False):
    host, port = address.rsplit(':', 1)
    conn = http.client.HTTPConnection(host.strip('[]'), int(port), timeout=10)
    data = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else None
    h = {'Content-Type': 'application/json', **(headers or {})}
    try:
        body = iter([data[:10], data[10:]]) if chunked and data else data
        conn.request('POST' if payload is not None else 'GET', path, body=body, headers=h, encode_chunked=chunked)
        res = conn.getresponse()
        return res.status, res.read().decode()
    finally:
        conn.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--binary', default=str(ROOT / 'strata-go-experimental'))
    p.add_argument('--idle-seconds', type=float, default=10)
    p.add_argument('--output', default=str(ROOT / 'endpoint-memory.json'))
    a = p.parse_args()
    binary = Path(a.binary).resolve()
    if not binary.is_file() or not os.access(binary, os.X_OK):
        p.error('Go executable is absent; endpoints and server memory cannot be measured')
    if not 1 <= a.idle_seconds <= 300:
        p.error('idle-seconds must be 1..300')
    report = {'scope': 'Go byte-fixture server PID only, no real model', 'os': platform.platform(), 'runtime_env': {k: os.environ.get(k, '(Go default)') for k in ('GOGC', 'GOMEMLIMIT', 'GOMAXPROCS')}, 'samples': [], 'checks': []}
    with tempfile.TemporaryDirectory(prefix='strata-go-exercise-') as temp:
        config = Path(temp) / 'config.json'
        config.write_text(json.dumps({'engine': 'mock', 'port': 0, 'script': 'Grüße 東京', 'context': 65536, 'api_key': 'isolated-fixture-key'}))
        proc = subprocess.Popen([str(binary), '--config', str(config)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            with selectors.DefaultSelector() as sel:
                sel.register(proc.stdout, selectors.EVENT_READ)
                if not sel.select(10):
                    raise RuntimeError('server did not announce its isolated listener')
                ready = json.loads(proc.stdout.readline())
            if ready.get('pid') != proc.pid or ready.get('production_ready') is not False:
                raise RuntimeError('unexpected fixture capability announcement')
            address = ready['address']
            report['pid'] = proc.pid
            report['samples'].append({'phase': 'startup', **memory(proc.pid)})
            headers = {'Authorization': 'Bearer isolated-fixture-key'}
            basic = {'model': 'strata-byte-fixture', 'messages': [{'role': 'user', 'content': 'hello'}]}
            def check(name, path, payload=None, expected=200, auth=True, extra=None, chunked=False):
                status, body = request(address, path, payload, {**(headers if auth else {}), **(extra or {})}, chunked)
                if status != expected:
                    raise AssertionError(f'{name}: {status} != {expected}: {body}')
                report['checks'].append({'name': name, 'status': status})
                return body
            check('unauthenticated health', '/health', auth=False)
            check('inference requires key', '/v1/models', expected=401, auth=False)
            check('Host protection', '/health', expected=403, extra={'Host': 'attacker.invalid'})
            check('Origin protection', '/health', expected=403, extra={'Origin': 'https://attacker.invalid'})
            check('models', '/v1/models')
            report['capabilities'] = json.loads(check('capabilities', '/props'))
            body = json.loads(check('chat', '/v1/chat/completions', basic))
            assert body['choices'][0]['message']['content'] == 'Grüße 東京'
            check('chunked body', '/v1/chat/completions', basic, chunked=True)
            stream = check('chat SSE', '/v1/chat/completions', {**basic, 'stream': True})
            assert stream.endswith('data: [DONE]\n\n')
            for path in ['/v1/messages', '/v1/v1/messages']:
                check('messages ' + path, path, basic)
                stream = check('messages SSE ' + path, path, {**basic, 'stream': True})
                assert 'event: message_stop' in stream
            for path in ['/v1/messages/count_tokens', '/v1/v1/messages/count_tokens']:
                check('count ' + path, path, basic)
            check('unsupported Responses', '/v1/responses', basic, expected=501)
            check('unsupported tools rejected', '/v1/chat/completions', {**basic, 'tools': []}, expected=400)
            check('oversized body', '/v1/chat/completions', {**basic, 'messages': [{'role': 'user', 'content': 'x' * ((1 << 20) + 4096)}]}, expected=413)
            report['samples'].append({'phase': 'after_representative_requests', **memory(proc.pid)})
            long = {**basic, 'messages': [{'role': 'user', 'content': 'x' * 50000}]}
            check('long fixture prompt', '/v1/chat/completions', long)
            with ThreadPoolExecutor(max_workers=4) as pool:
                futures = [pool.submit(request, address, '/v1/chat/completions', basic, headers) for _ in range(12)]
                for f in futures:
                    status, body = f.result()
                    if status != 200:
                        raise AssertionError((status, body))
            report['checks'].append({'name': '12 requests with 4 concurrent clients', 'status': 200})
            report['samples'].append({'phase': 'after_long_and_concurrent_requests', **memory(proc.pid)})
            time.sleep(a.idle_seconds)
            report['samples'].append({'phase': 'idle_after_workload', 'idle_seconds': a.idle_seconds, **memory(proc.pid)})
            report['idle_target_MiB'] = 20
            report['idle_target_met_for_fixture_only'] = report['samples'][-1]['VmRSS_KiB'] <= 20 * 1024
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=3)
            report['exit_code'] = proc.returncode
            report['stderr'] = proc.stderr.read()
            proc.stdout.close()
            proc.stderr.close()
            Path(a.output).write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()

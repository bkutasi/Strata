package main
import("context";"crypto/rand";"encoding/hex";"encoding/json";"errors";"flag";"fmt";"io";"log";"net";"net/http";"os";"os/signal";"runtime";"strconv";"strings";"syscall";"time")
type Config struct{
 Host string `json:"host"`;Port int `json:"port"`;APIKey string `json:"api_key"`
 Engine string `json:"engine"`;EngineCommand []string `json:"engine_command"`;Script string `json:"script"`
 Context int `json:"context"`;MaxBody int64 `json:"max_body_bytes"`;Queue int `json:"queue_limit"`
 TimeoutSeconds int `json:"request_timeout_s"`;DelayMS int `json:"mock_delay_ms"`;Thinking bool `json:"thinking"`
}
func defaultConfig()Config{return Config{Host:"127.0.0.1",Port:8095,Context:32768,MaxBody:1<<20,Queue:16,TimeoutSeconds:60,Script:"Hello from the explicit mock engine."}}
func validateConfig(c Config)error{
 ip:=net.ParseIP(c.Host);if ip==nil||!ip.IsLoopback(){return errors.New("fixture server binds only to literal loopback addresses")}
 if c.Port<0||c.Port>65535{return errors.New("port must be 0..65535")}
 if c.Context<64||c.Context>1<<20{return errors.New("context must be 64..1048576 fixture bytes")}
 if c.MaxBody<1||c.MaxBody>16<<20{return errors.New("max_body_bytes must be 1..16777216")}
 if c.Queue<0||c.Queue>1024{return errors.New("queue_limit must be 0..1024")}
 if c.TimeoutSeconds<1||c.TimeoutSeconds>3600{return errors.New("request_timeout_s must be 1..3600")}
 if c.DelayMS<0||c.DelayMS>10000{return errors.New("mock_delay_ms must be 0..10000")}
 if c.Engine!="mock"&&c.Engine!="protocol-fixture"{return errors.New("explicit --engine mock or protocol-fixture required; real-model mode is not implemented")}
 if c.Engine=="protocol-fixture"&&len(c.EngineCommand)==0{return errors.New("protocol-fixture requires engine_command")};return nil
}
func newID(prefix string)string{var b [12]byte;if _,err:=rand.Read(b[:]);err!=nil{panic(err)};return prefix+hex.EncodeToString(b[:])}
func capability()map[string]any{return map[string]any{
 "implementation":"strata-go-experimental","schema_version":1,"revision":"fixture-http-tools-v3","production_ready":false,"go_version":runtime.Version(),"go_os":runtime.GOOS,"go_arch":runtime.GOARCH,
 "engine_modes":[]string{"mock","protocol-fixture"},"tokenizer":"byte fixture only","template":"JSON fixture only","fixture_http_tools":true,"tool_output_commit":"after engine DONE and validation",
 "fixture_routes":[]string{"/health","/v1/models","/models","/status","/v1/status","/props","/metrics","/metrics/prometheus","/v1/chat/completions","/v1/messages","/v1/messages/count_tokens"},
 "unsupported":[]string{"real models","family tokenization","Jinja templates","Responses","production HTTP tool parity","vision","MCP","image generation","batching","replicas","split serving","sessions","settings","load/unload","VRAM","telemetry credentials","manager readiness/ownership","desktop/CLI integration","Windows job objects","browser UI"},
}}
func run()error{
 cfg:=defaultConfig();fs:=flag.NewFlagSet("strata-go-experimental",flag.ContinueOnError)
 configPath:=fs.String("config","","standalone config, NOT a Strata run config");engine:=fs.String("engine","","mock or protocol-fixture")
 host:=fs.String("host","","literal loopback address");port:=fs.Int("port",-1,"port; 0 selects an isolated port")
 keyEnv:=fs.String("api-key-env","","environment variable containing optional inference key");caps:=fs.Bool("capabilities",false,"print limitations and exit")
 if err:=fs.Parse(os.Args[1:]);err!=nil{return err};if fs.NArg()!=0{return errors.New("unexpected positional arguments")}
 if *caps{return json.NewEncoder(os.Stdout).Encode(capability())}
 if *configPath!=""{
  data,err:=os.ReadFile(*configPath);if err!=nil{return err};if len(data)>1<<20{return errors.New("config exceeds 1 MiB")}
  dec:=json.NewDecoder(strings.NewReader(strings.TrimPrefix(string(data),"\ufeff")));dec.DisallowUnknownFields()
  if err=dec.Decode(&cfg);err!=nil{return fmt.Errorf("standalone config: %w",err)}
  var extra any;if err=dec.Decode(&extra);err!=io.EOF{return errors.New("trailing config data")}
 }
 if *engine!=""{cfg.Engine=*engine};if *host!=""{cfg.Host=*host};if *port>=0{cfg.Port=*port}
 if *keyEnv!=""{value,ok:=os.LookupEnv(*keyEnv);if !ok||value==""{return errors.New("API key environment variable is unset or empty")};cfg.APIKey=value}
 if err:=validateConfig(cfg);err!=nil{return err}
 ctx,stop:=signal.NotifyContext(context.Background(),os.Interrupt,syscall.SIGTERM);defer stop()
 var e Engine=&ByteEngine{Script:cfg.Script,Delay:time.Duration(cfg.DelayMS)*time.Millisecond}
 if cfg.Engine=="protocol-fixture"{wire,err:=startWire(ctx,cfg.EngineCommand,time.Duration(cfg.TimeoutSeconds)*time.Second);if err!=nil{return err};e=wire;cfg.Context=wire.contextSize}
 defer e.Close();app:=newService(cfg,e)
 listener,err:=net.Listen("tcp",net.JoinHostPort(cfg.Host,strconv.Itoa(cfg.Port)));if err!=nil{return err};defer listener.Close();app.authority=listener.Addr().String()
 server:=&http.Server{Handler:app,ReadHeaderTimeout:5*time.Second,ReadTimeout:15*time.Second,IdleTimeout:30*time.Second,MaxHeaderBytes:16<<10,BaseContext:func(net.Listener)context.Context{return ctx}}
 // Standalone stdout announcement, NOT the Strata manager's readiness contract.
 if err=json.NewEncoder(os.Stdout).Encode(map[string]any{"experimental":true,"pid":os.Getpid(),"address":app.authority,"mode":cfg.Engine,"production_ready":false});err!=nil{return err}
 ended:=make(chan error,1);go func(){ended<-server.Serve(listener)}()
 select{case err=<-ended:if errors.Is(err,http.ErrServerClosed){return nil};return err;case <-ctx.Done():}
 app.queue.Stop();shutdown,cancel:=context.WithTimeout(context.Background(),5*time.Second);defer cancel()
 if err=server.Shutdown(shutdown);err!=nil{_ = server.Close();return err};return nil
}
func main(){if err:=run();err!=nil{log.Print(err);os.Exit(1)}}

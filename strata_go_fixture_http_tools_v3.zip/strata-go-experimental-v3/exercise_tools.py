"""Offline tool HTTP exercise against an already-built Go binary.
Only loopback fixture traffic. No downloads, model inference or memory claims.
"""
import argparse
from contextlib import contextmanager
import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import tempfile
from exercise import request

ROOT = Path(__file__).resolve().parent
CALL = '<tool_call><function=read><parameter=path>123</parameter><parameter=n>9007199254740993</parameter><parameter=flag>true</parameter><parameter=arr>[1,"東京"]</parameter></function></tool_call>'
EXPECTED = {'path': '123', 'n': 9007199254740993, 'flag': True, 'arr': [1, '東京']}


def payload(anthropic, stream=False):
    schema = {'type': 'object', 'properties': {'path': {'type': 'string'}, 'n': {'type': 'integer'}, 'flag': {'type': 'boolean'}, 'arr': {'type': 'array'}}, 'required': ['path'], 'additionalProperties': False}
    tool = {'name': 'read', 'input_schema': schema} if anthropic else {'type': 'function', 'function': {'name': 'read', 'parameters': schema}}
    return {'model': 'strata-byte-fixture', 'messages': [{'role': 'user', 'content': 'Grüße 東京'}], 'tools': [tool], 'stream': stream}


def endpoint(anthropic):
    return '/v1/messages' if anthropic else '/v1/chat/completions'


@contextmanager
def server(binary, mode, script, fault=None):
    with tempfile.TemporaryDirectory(prefix='strata-tools-v3-') as temp:
        config = {'engine': mode, 'host': '127.0.0.1', 'port': 0, 'context': 65536, 'request_timeout_s': 10, 'api_key': 'isolated-tools-key'}
        if mode == 'mock':
            config['script'] = script
        else:
            config['engine_command'] = [sys.executable, '-u', str(ROOT / 'fake_engine.py'), '--context', '65536', '--script', script]
            if fault:
                config['engine_command'] += ['--fault', fault]
        path = Path(temp) / 'config.json'
        path.write_text(json.dumps(config, ensure_ascii=False))
        proc = subprocess.Popen([str(binary), '--config', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            with selectors.DefaultSelector() as sel:
                sel.register(proc.stdout, selectors.EVENT_READ)
                if not sel.select(15):
                    raise RuntimeError('fixture startup deadline exceeded')
                ready = json.loads(proc.stdout.readline())
            if ready.get('pid') != proc.pid or ready.get('production_ready') is not False:
                raise RuntimeError('unexpected readiness announcement')
            yield ready['address']
        finally:
            if proc.poll() is None:
                proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=3)
            stderr = proc.stderr.read()
            proc.stdout.close()
            proc.stderr.close()
            if proc.returncode not in (0, -15):
                raise RuntimeError(f'fixture process exit {proc.returncode}: {stderr}')


def parse_frames(body):
    out = []
    event = ''
    for line in body.splitlines():
        if line.startswith('event: '):
            event = line[7:]
        elif line.startswith('data: '):
            data = line[6:]
            out.append((event, data if data == '[DONE]' else json.loads(data)))
            event = ''
    return out


def calls_from(body, anthropic, stream):
    if not stream:
        obj = json.loads(body)
        if anthropic:
            assert obj['stop_reason'] == 'tool_use', obj
            return [{'id': b['id'], 'name': b['name'], 'args': b['input']} for b in obj['content'] if b['type'] == 'tool_use']
        choice = obj['choices'][0]
        assert choice['finish_reason'] == 'tool_calls', choice
        return [{'id': c['id'], 'name': c['function']['name'], 'args': json.loads(c['function']['arguments'])} for c in choice['message']['tool_calls']]
    frames = parse_frames(body)
    calls = []
    if anthropic:
        assert frames[0][0] == 'message_start' and frames[-1][0] == 'message_stop', frames
        assert frames[-2][1]['delta']['stop_reason'] == 'tool_use', frames
        active = None
        for event, data in frames:
            if event == 'content_block_start' and data['content_block']['type'] == 'tool_use':
                b = data['content_block']
                active = {'id': b['id'], 'name': b['name'], 'args': None}
            elif event == 'content_block_delta' and data['delta']['type'] == 'input_json_delta':
                assert active is not None
                active['args'] = json.loads(data['delta']['partial_json'])
            elif event == 'content_block_stop' and active is not None:
                assert active['args'] is not None
                calls.append(active)
                active = None
    else:
        assert frames[-1][1] == '[DONE]', frames
        assert frames[-2][1]['choices'][0]['finish_reason'] == 'tool_calls', frames
        for _, data in frames:
            if data == '[DONE]':
                continue
            for c in data['choices'][0]['delta'].get('tool_calls', []):
                assert c['index'] == len(calls)
                calls.append({'id': c['id'], 'name': c['function']['name'], 'args': json.loads(c['function']['arguments'])})
    return calls


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--binary', default=str(ROOT / 'strata-go-experimental'))
    parser.add_argument('--output', default=str(ROOT / 'tool-endpoints-v3.json'))
    args = parser.parse_args()
    binary = Path(args.binary).resolve()
    if not binary.is_file() or not os.access(binary, os.X_OK):
        parser.error('Go executable absent; HTTP tool checks are not run')
    report = {'revision': 'fixture-http-tools-v3', 'scope': 'isolated byte fixtures only', 'passed': False, 'checks': []}
    headers = {'Authorization': 'Bearer isolated-tools-key'}

    def check(address, mode, anthropic, stream, req, count=2):
        status, body = request(address, endpoint(anthropic), req, headers)
        assert status == 200, (status, body)
        calls = calls_from(body, anthropic, stream)
        assert len(calls) == count and len({c['id'] for c in calls}) == count, calls
        assert all(c['name'] == 'read' and c['args'] == EXPECTED for c in calls), calls
        report['checks'].append({'mode': mode, 'anthropic': anthropic, 'stream': stream, 'calls': count, 'status': 'passed'})
        return calls

    try:
        for mode in ('mock', 'protocol-fixture'):
            with server(binary, mode, CALL + CALL) as address:
                for anthropic in (False, True):
                    for stream in (False, True):
                        req = payload(anthropic, stream)
                        check(address, mode, anthropic, stream, req)
                    req = payload(anthropic)
                    calls = check(address, mode, anthropic, False, req)
                    if anthropic:
                        req['messages'] = [{'role': 'assistant', 'content': [{'type': 'tool_use', 'id': c['id'], 'name': c['name'], 'input': c['args']} for c in calls]}, {'role': 'user', 'content': [{'type': 'tool_result', 'tool_use_id': c['id'], 'content': 'résultat 東京'} for c in reversed(calls)]}]
                    else:
                        req['messages'] = [{'role': 'assistant', 'content': None, 'tool_calls': [{'id': c['id'], 'type': 'function', 'function': {'name': c['name'], 'arguments': json.dumps(c['args'], ensure_ascii=False)}} for c in calls]}] + [{'role': 'tool', 'tool_call_id': c['id'], 'content': 'résultat 東京'} for c in reversed(calls)]
                    check(address, mode, anthropic, False, req)
                    req = payload(anthropic, True)
                    req['tool_choice'] = {'type': 'none'} if anthropic else 'none'
                    status, body = request(address, endpoint(anthropic), req, headers)
                    assert status == 200 and '"error"' in body and '[DONE]' not in body and 'event: message_stop' not in body, body
                    report['checks'].append({'mode': mode, 'case': 'none rejects generated call', 'anthropic': anthropic, 'status': 'passed'})
            continuation = CALL.removeprefix('<tool_call><function=read>')
            with server(binary, mode, continuation) as address:
                for anthropic in (False, True):
                    for named in (False, True):
                        req = payload(anthropic, True)
                        req['tool_choice'] = ({'type': 'tool', 'name': 'read'} if named else {'type': 'any'}) if anthropic else ({'type': 'function', 'function': {'name': 'read'}} if named else 'required')
                        check(address, mode, anthropic, True, req, count=1)
            with server(binary, mode, CALL + '<tool_call>') as address:
                for anthropic in (False, True):
                    for stream in (False, True):
                        status, body = request(address, endpoint(anthropic), payload(anthropic, stream), headers)
                        assert status == (200 if stream else 502), (status, body)
                        assert '"error"' in body and '[DONE]' not in body and 'event: message_stop' not in body and '"name":"read"' not in body, body
                        report['checks'].append({'mode': mode, 'case': 'incomplete output atomic failure', 'anthropic': anthropic, 'stream': stream, 'status': 'passed'})
        report['passed'] = True
    except Exception as exc:
        report['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        Path(args.output).write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()

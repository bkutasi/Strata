"""Exec-wrapper tests with temporary executable/module fixtures, not a Go binary."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent


class LauncherTests(unittest.TestCase):
    def test_default_python_forwarding(self):
        with tempfile.TemporaryDirectory() as temp:
            package = Path(temp) / 'serve'
            package.mkdir()
            (package / '__init__.py').write_text('')
            (package / 'server.py').write_text('import os,sys,json; print(json.dumps({"pid":os.getpid(),"args":sys.argv[1:]}))')
            env = {**os.environ, 'PYTHONPATH': temp}
            proc = subprocess.Popen([sys.executable, str(ROOT / 'launch.py'), '--port', '9999'], cwd=temp, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            out, err = proc.communicate(timeout=10)
            self.assertEqual(proc.returncode, 0, err)
            result = json.loads(out)
            self.assertEqual(result['pid'], proc.pid)
            self.assertEqual(result['args'], ['--port', '9999'])

    def test_explicit_go_exec_forwarding(self):
        with tempfile.TemporaryDirectory() as temp:
            binary = Path(temp) / 'exec-fixture'
            binary.write_text('#!' + sys.executable + '\nimport os,sys,json\nprint(json.dumps({"pid":os.getpid(),"args":sys.argv[1:]}))\n')
            binary.chmod(0o700)
            proc = subprocess.Popen([sys.executable, str(ROOT / 'launch.py'), '--server', 'go', '--go-binary', str(binary), '--engine', 'mock'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            out, err = proc.communicate(timeout=10)
            self.assertEqual(proc.returncode, 0, err)
            result = json.loads(out)
            self.assertEqual(result['pid'], proc.pid)
            self.assertEqual(result['args'], ['--engine', 'mock'])

    def test_missing_go_does_not_fallback(self):
        with tempfile.TemporaryDirectory() as temp:
            result = subprocess.run([sys.executable, str(ROOT / 'launch.py'), '--server', 'go', '--go-binary', str(Path(temp) / 'absent')], capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 2)
            self.assertIn('no silent fallback', result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)

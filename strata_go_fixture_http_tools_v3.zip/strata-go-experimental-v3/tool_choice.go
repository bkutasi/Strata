package main

import "strings"

// Unknown choices intentionally degrade to auto at forcedCall, matching the handoff.
// HTTP request validation is stricter than these pure helpers. No grammar enforcement is implied.
func toolChoiceOf(choice any) (string,string) {
 if s,ok:=choice.(string);ok {switch s{case "auto","none","required":return s,""};return "unknown",""}
 obj,ok:=choice.(map[string]any);if !ok{return "unknown",""}
 kind,_:=obj["type"].(string)
 switch kind {
 case "auto","none":return kind,""
 case "any":return "required",""
 case "function","tool":
  name:="";if fn,ok:=obj["function"].(map[string]any);ok{name,_=fn["name"].(string)}
  if name==""{name,_=obj["name"].(string)};if name!=""{return "named",name}
 }
 return "unknown",""
}
func forcedCall(choice any,tools []map[string]any) string {
 kind,name:=toolChoiceOf(choice);names:=map[string]bool{}
 for _,tool:=range tools{if n,ok:=tool["name"].(string);ok&&n!=""{names[n]=true}}
 if kind=="required"&&len(names)==1{for n:=range names{name=n};kind="named"}
 if kind=="named"&&names[name] {
  // Trust-boundary guard: invalid markup names must never become protocol syntax.
  // This is a deliberate stricter assumption, not verified Python parity.
  if strings.ContainsAny(name,"<>\r\n"){return ""}
  return "<tool_call>\n<function="+name+">"
 }
 if kind=="required"&&len(names)>0{return "<tool_call>\n<function="}
 return ""
}

"""Deterministic line-protocol fixture. Not an inference engine or tokenizer."""
import argparse
import sys
import threading


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--script', default='wire fixture')
    p.add_argument('--context', type=int, default=32768)
    p.add_argument('--delay', type=float, default=0)
    p.add_argument('--hold-after-first', action='store_true', help='event-controlled cancellation fixture')
    p.add_argument('--fault', choices=['none', 'error', 'eof', 'invalid-token', 'nonfinite', 'stall'], default='none')
    a = p.parse_args()
    if not 64 <= a.context <= 1048576 or not 0 <= a.delay <= 10:
        p.error('invalid fixture context or delay')
    lock = threading.Lock()
    cancel = threading.Event()
    active = threading.Event()
    worker = None

    def send(line):
        with lock:
            print(line, flush=True)

    def terminal(line):
        active.clear()
        send(line)

    def generate(cap):
        if a.fault == 'stall':
            cancel.wait()
            terminal('DONE finish=stop')
            return
        if a.fault == 'error':
            terminal('ERR fixture failure')
            return
        if a.fault == 'eof':
            # A controlled crash fixture; no buffered output is required after READY.
            import os
            os._exit(7)
        if a.fault in ('invalid-token', 'nonfinite'):
            terminal('T invalid' if a.fault == 'invalid-token' else 'ERR nonfinite logits')
            return
        data = a.script.encode('utf-8')
        for index, token in enumerate(data[:cap]):
            if cancel.wait(a.delay):
                terminal('DONE finish=stop')
                return
            send(f'T {token}')
            if a.hold_after_first and index == 0:
                cancel.wait()
                terminal('DONE finish=stop')
                return
        terminal('DONE finish=' + ('length' if len(data) > cap else 'stop'))

    send(f'READY {a.context} stop fixture-byte-v1')
    try:
        for raw in sys.stdin:
            line = raw.rstrip('\r\n')
            if line == 'QUIT':
                break
            if line == 'STOP':
                cancel.set()
                if worker:
                    worker.join(timeout=2)
                continue
            if active.is_set():
                send('ERR fixture busy')
                continue
            try:
                command, count, ids = line.split(' ', 2)
                if command != 'GEN':
                    raise ValueError('unsupported command')
                cap = int(count)
                prompt = [int(x) for x in ids.split(',')] if ids else []
                if not 0 < cap <= a.context or any(not 0 <= x <= 255 for x in prompt):
                    raise ValueError('invalid fixture token or limit')
            except ValueError:
                send('ERR malformed fixture GEN')
                continue
            cancel.clear()
            active.set()
            worker = threading.Thread(target=generate, args=(cap,))
            worker.start()
    finally:
        cancel.set()
        if worker:
            worker.join(timeout=2)


if __name__ == '__main__':
    main()

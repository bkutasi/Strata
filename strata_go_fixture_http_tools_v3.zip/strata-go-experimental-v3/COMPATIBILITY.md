# Compatibility: fixture-http-tools-v3

Implemented-source does not mean compiled or verified. All current Go execution is blocked by the missing compiler. User v2 evidence is separate.

| Feature | Implementation | Fixture-tested here | Current Go-tested | Parity / gap |
|---|---|---|---|---|
| Confirmed param_end correction | implemented-source | Python reference regression passed | not run | Exact supplied condition reflected; full parity unverified |
| Tool definitions / choices / schema subset | implemented-source | not HTTP-tested here | not run | Strict supported subset; see ASSUMPTIONS.md |
| Synthetic tool transcript and result replay | implemented-source | not HTTP-tested here | not run | Explicit fixture format, no model template |
| OpenAI tool responses, nonstream / SSE | implemented-source | not HTTP-tested here | not run | Fixture event contract, not upstream parity |
| Anthropic tool responses, nonstream / SSE | implemented-source | not HTTP-tested here | not run | Separate block events; no full upstream parity |
| Transactional error / cancellation behavior | implemented-source | Go tests supplied, unrun | not run | Commit after engine success; partial network writes remain possible |
| Mock and protocol-fixture bridge | retained-source plus HTTP wiring | Python fake-engine tests passed | current wiring unrun; v2 user-tested | Native models unavailable |
| Legacy fixture HTTP / security / queue | retained or extended-source | Python support only | current HTTP unrun; v2 user-tested | No full Strata compatibility established |
| Python launcher default | retained-source | 3 launcher tests passed | not applicable | Standalone only; no upstream integration |
| Parser oracle corpus | implemented | 39 cases generated; 6 Python reference tests passed | Go differential test unrun | Reference is partial, not full original module |
| Quoted/fenced markers / aliases / recovery / DSML | missing or partial | not established | not run | No completeness claim |
| Production tokenizer / templates / real engine | missing / blocked | not tested | not run | No model/vocabulary assets or parity oracle |
| Responses / vision / MCP / images / sessions / replicas / split | missing | not tested | not run | Unavailable |
| CLI / desktop / packaging / manager ownership | missing | not integrated | not run | Python default unchanged |
| Production 20 MiB memory target | blocked / unmeasured | no current Go process | not run | 13,188 KiB belongs only to user v2 fixture run |
| Browser UI | excluded | not tested | not run | Explicit compatibility difference |

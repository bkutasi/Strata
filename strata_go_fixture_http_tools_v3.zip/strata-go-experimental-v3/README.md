# Strata Go experimental: fixture-http-tools-v3

Complete source continuation of parser-lifecycle-v2. **Fixture only; not a production replacement. Current Go build/tests/HTTP execution are unrun here.**

- Confirmed final partial-follower parser correction.
- Tool definition/choice validation, schema-aware parsing, synthetic call/result replay and API-specific OpenAI/Anthropic responses, streaming and nonstreaming.
- Tool-aware output commits only after engine success and validation. Tools are declarations; this server does not execute them.
- Python remains the standalone launcher default. No upstream CLI/desktop/packaging integration is claimed. Native model mode remains unavailable.

Read `REPORT.md`, `ASSUMPTIONS.md`, `COMPATIBILITY.md` and `compatibility.json` before using the experimental path. User external v2 results are under `v2-evidence/`, separate from current evidence.

## Offline verification

From this directory, with Go 1.22+, a C compiler and Python 3.9+ already installed:

```sh
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go vet ./...
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go test -race -count=1 -timeout=180s ./...
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go build -trimpath -o strata-go-experimental .
python3 -m unittest -v test_fixture test_launch test_excerpt_oracle
python3 exercise.py --idle-seconds 1 --output endpoint-memory-v3.json
python3 exercise_tools.py --output tool-endpoints-v3.json

```

No third-party Go modules are required. `python3 verify.py` combines Python tests, gofmt, vet, race tests and build; the HTTP exercises remain separate. A missing compiler or binary is a failure, not a pass.

## Fixtures

`tools-mock.json` and `tools-protocol-fixture.json` emit two automatic calls. `tool-request-openai.json` and `tool-request-anthropic.json` declare their schemas. The matching `tool-replay-*.json` files demonstrate client-supplied result replay with illustrative IDs.

Forced/required choices expect the script continuation after the prefix described in `ASSUMPTIONS.md`; automatic choices expect full envelopes. General marker quoting/fences, aliases, recovery and DSML are not complete. No production memory target is measured.

Use `FEEDBACK.txt` to report external results. All v2 tests remain, with the confirmed incorrect boundary assertion corrected and archived.

package main
import("context";"crypto/sha256";"crypto/subtle";"encoding/json";"errors";"fmt";"io";"mime";"net/http";"net/url";"strings";"sync/atomic";"time")
type service struct{cfg Config;engine Engine;queue *FIFO;authority string;admission chan struct{};completed atomic.Uint64;failed atomic.Uint64}
func newService(c Config,e Engine)*service{return &service{cfg:c,engine:e,queue:&FIFO{max:c.Queue},admission:make(chan struct{},c.Queue+1)}}
func writeJSON(w http.ResponseWriter,status int,v any){w.Header().Set("Content-Type","application/json");w.WriteHeader(status);_ = json.NewEncoder(w).Encode(v)}
func apiError(w http.ResponseWriter,status int,message string){writeJSON(w,status,map[string]any{"error":map[string]any{"message":message,"type":"invalid_request_error","code":nil,"param":nil}})}
func(s *service) authorized(r *http.Request)bool{
 if s.cfg.APIKey==""{return true};a:="";if h:=r.Header.Get("Authorization");strings.HasPrefix(h,"Bearer "){a=strings.TrimPrefix(h,"Bearer ")};b:=r.Header.Get("x-api-key")
 expected:=sha256.Sum256([]byte(s.cfg.APIKey));aa:=sha256.Sum256([]byte(a));bb:=sha256.Sum256([]byte(b))
 return subtle.ConstantTimeCompare(expected[:],aa[:])|subtle.ConstantTimeCompare(expected[:],bb[:])==1
}
func(s *service) ServeHTTP(w http.ResponseWriter,r *http.Request){
 w.Header().Set("Cache-Control","no-store");w.Header().Set("X-Content-Type-Options","nosniff")
 if r.Host!=s.authority{apiError(w,403,"Host does not match this isolated listener");return}
 if origin:=r.Header.Get("Origin");origin!=""{u,err:=url.Parse(origin);if err!=nil||u.Scheme!="http"||u.Host!=s.authority||u.Path!=""||u.RawQuery!=""||u.Fragment!=""||u.User!=nil{apiError(w,403,"cross-origin requests disabled");return}}
 path:=r.URL.Path
 if path=="/health"{if r.Method!="GET"{apiError(w,405,"method not allowed");return};writeJSON(w,200,map[string]any{"status":"ok","experimental":true,"production_ready":false});return}
 if !s.authorized(r){apiError(w,401,"invalid API key");return}
 if path=="/v1/v1/messages"{path="/v1/messages"};if path=="/v1/v1/messages/count_tokens"{path="/v1/messages/count_tokens"}
 switch path{
 case "/v1/models","/models","/status","/v1/status","/props","/metrics","/metrics/prometheus":
  if r.Method!="GET"{apiError(w,405,"method not allowed");return};busy,queued:=s.queue.State()
  switch path{
  case "/v1/models","/models":writeJSON(w,200,map[string]any{"object":"list","data":[]any{map[string]any{"id":"strata-byte-fixture","object":"model","created":0,"owned_by":"fixture"}}})
  case "/props":writeJSON(w,200,capability())
  case "/metrics/prometheus":w.Header().Set("Content-Type","text/plain; version=0.0.4");_,_ = fmt.Fprintf(w,"strata_fixture_requests_completed_total %d\nstrata_fixture_requests_failed_total %d\nstrata_fixture_requests_queued %d\n",s.completed.Load(),s.failed.Load(),queued)
  default:writeJSON(w,200,map[string]any{"busy":busy,"queued":queued,"completed":s.completed.Load(),"failed":s.failed.Load(),"experimental":true})
  };return
 case "/v1/responses","/v1/telemetry","/slots","/settings","/v1/vram","/v1/load","/v1/unload":apiError(w,501,"not implemented; see /props");return
 case "/v1/chat/completions","/v1/messages","/v1/messages/count_tokens":if r.Method!="POST"{apiError(w,405,"method not allowed");return}
 default:apiError(w,404,"unknown endpoint");return
 }
 select{case s.admission<-struct{}{}:defer func(){<-s.admission}();default:apiError(w,503,"HTTP admission full");return}
 req,err:=s.decode(w,r,path);if err!=nil{var large *http.MaxBytesError;if errors.As(err,&large){apiError(w,413,"request body exceeds limit")}else{apiError(w,400,err.Error())};return}
 if path=="/v1/messages/count_tokens"{writeJSON(w,200,map[string]any{"input_tokens":len(req.prompt)});return}
 ctx,cancel:=context.WithTimeout(r.Context(),time.Duration(s.cfg.TimeoutSeconds)*time.Second);defer cancel()
 release,err:=s.queue.Acquire(ctx);if err!=nil{apiError(w,503,err.Error());return};defer release();s.generate(w,r.WithContext(ctx),req)
}
type message struct{Role string `json:"role"`;Content string `json:"content"`}
type request struct{
 messages []message;prompt []byte;cap int;stream bool;anthropic bool
 tools []fixtureTool;schemas map[string]map[string]any;choice string;named string;prefix string;usedIDs map[string]bool
}
func(s *service) decode(w http.ResponseWriter,r *http.Request,path string)(request,error){
 out:=request{anthropic:path!="/v1/chat/completions"}
 kind,_,err:=mime.ParseMediaType(r.Header.Get("Content-Type"));if err!=nil||kind!="application/json"{return out,errors.New("Content-Type must be application/json")}
 r.Body=http.MaxBytesReader(w,r.Body,s.cfg.MaxBody);defer r.Body.Close();data,err:=io.ReadAll(r.Body);if err!=nil{return out,err}
 decoded,err:=decodeToolJSON(string(data));if err!=nil{return out,err};raw,err:=object(decoded,"body");if err!=nil{return out,err}
 allowed:=[]string{"model","messages","stream","max_tokens","tools","tool_choice"};if out.anthropic{allowed=append(allowed,"system")}else{allowed=append(allowed,"max_completion_tokens")};if err=fields(raw,allowed...);err!=nil{return out,err}
 if model,ok:=raw["model"];ok{if name,ok:=model.(string);!ok||name!="strata-byte-fixture"{return out,errors.New("model must be strata-byte-fixture")}}
 if v,ok:=raw["stream"];ok{var valid bool;out.stream,valid=v.(bool);if !valid{return out,errors.New("stream must be boolean")}}
 out.tools,out.schemas,out.choice,out.named,err=normalizeTools(raw,out.anthropic);if err!=nil{return out,err}
 turns,err:=fixtureHistory(raw,out.anthropic,out.schemas);if err!=nil{return out,err}
 out.usedIDs=map[string]bool{};for _,turn:=range turns{for _,call:=range turn.Calls{out.usedIDs[call.ID]=true}}
 // Preserve the legacy text-only prompt bytes. Tool-aware prompts are explicitly synthetic.
 if len(out.tools)==0{
  for _,turn:=range turns{out.messages=append(out.messages,message{turn.Role,turn.Content})};out.prompt,err=json.Marshal(out.messages)
 }else{
  toolMaps:=[]map[string]any{};for _,tool:=range out.tools{toolMaps=append(toolMaps,map[string]any{"name":tool.Name})}
  var choice any=out.choice;if out.choice=="named"{choice=map[string]any{"type":"tool","name":out.named}}
  out.prefix=forcedCall(choice,toolMaps)
  out.prompt,err=json.Marshal(map[string]any{"fixture_format":"strata-byte-tools-v1","not_a_model_template":true,"messages":turns,"tools":out.tools,"tool_choice":map[string]any{"kind":out.choice,"name":out.named},"forced_prefix":out.prefix})
 }
 if err!=nil{return out,err};room:=s.cfg.Context-len(out.prompt)-8;if room<=0{return out,errors.New("prompt exceeds fixture context")}
 limit:=0;for _,key:=range []string{"max_tokens","max_completion_tokens"}{if v,ok:=raw[key];ok{n,ok:=v.(json.Number);if !ok{return out,fmt.Errorf("%s must be an integer",key)};value,err:=n.Int64();if err!=nil||int64(int(value))!=value{return out,errors.New("output limit is out of range or not an integer")};limit=int(value)}}
 if _,a:=raw["max_tokens"];a{if _,b:=raw["max_completion_tokens"];b{return out,errors.New("provide only one output limit")}}
 if limit < -1{return out,errors.New("output limit must be -1, 0 or positive")};if limit<=0||limit>room{limit=room};out.cap=limit;return out,nil
}
type generation struct{event Event;events []Event;finish string;err error;done bool;tokens int}
func(s *service) produce(ctx context.Context,req request,ch chan<- generation){
 defer close(ch)
 send:=func(v generation)error{if err:=ctx.Err();err!=nil{return err};select{case ch<-v:return nil;case <-ctx.Done():return ctx.Err()}}
 thinking:=s.cfg.Thinking&&req.prefix==""
 parser:=NewParser(thinking,ParserOptions{Schemas:req.schemas,DeclaredOnly:true});detok:=Detokenizer{};tokens,calls:=0,0
 // Tool-aware output is a transaction: publish no call or block until engine DONE,
 // complete parsing, choice checks and all schema checks have succeeded.
 buffered:=[]Event{};var text strings.Builder;textKind:="";bufferedBytes:=0
 flush:=func(){if text.Len()>0{buffered=append(buffered,Event{Kind:textKind,Text:text.String()});text.Reset()}}
 emitEvents:=func(events []Event)error{
  for _,ev:=range events{
   if err:=ctx.Err();err!=nil{return err}
   if ev.Call!=nil{
    if req.choice=="none"{return errors.New("tool output forbidden by tool_choice none")}
    if err:=validateCall(ev.Call,req.schemas);err!=nil{return err}
    if req.choice=="named"&&ev.Call.Name!=req.named{return errors.New("output does not match named tool choice")}
    calls++;if calls>64{return errors.New("output exceeds 64 tool calls")}
    prefix:="call_";if req.anthropic{prefix="toolu_"}
    for{ev.Call.ID=newID(prefix);if !req.usedIDs[ev.Call.ID]{break}}
    req.usedIDs[ev.Call.ID]=true;flush();buffered=append(buffered,ev)
   }else if len(req.tools)>0{
    bufferedBytes+=len(ev.Text);if bufferedBytes>1<<20{return errors.New("tool transaction text exceeds 1 MiB")}
    if ev.Kind!=textKind{flush();textKind=ev.Kind};text.WriteString(ev.Text)
   }else{if err:=send(generation{event:ev});err!=nil{return err}}
  };return nil
 }
 if req.prefix!=""{events,err:=parser.Feed(req.prefix,false);if err!=nil{_ = send(generation{done:true,err:err});return};if err=emitEvents(events);err!=nil{_ = send(generation{done:true,err:err});return}}
 ids:=make([]int,len(req.prompt));for i,b:=range req.prompt{ids[i]=int(b)}
 finish,err:=s.engine.Generate(ctx,ids,req.cap,func(id int)error{
  if id<0||id>255{return errors.New("protocol-fixture tokens must be bytes (0..255)")};tokens++;if tokens>req.cap{return errors.New("engine exceeded output limit")}
  text,err:=detok.Feed([]byte{byte(id)},false);if err!=nil{return err};events,err:=parser.Feed(text,false);if err!=nil{return err};return emitEvents(events)
 })
 if err==nil{var text string;text,err=detok.Feed(nil,true);if err==nil{var events []Event;events,err=parser.Feed(text,true);if err==nil{err=emitEvents(events)}}}
 if err==nil&&finish!="stop"&&finish!="length"{err=errors.New("unsupported engine finish")}
 if err==nil&&(req.choice=="required"||req.choice=="named")&&calls==0{err=errors.New("required tool call was not produced")}
 if err==nil&&calls>0&&finish!="stop"{err=errors.New("tool transaction was truncated")}
 if err==nil{err=ctx.Err()}
 if err!=nil{buffered=nil}else{flush()}
 _ = send(generation{finish:finish,err:err,done:true,tokens:tokens,events:buffered})
}
func openAICall(call *Call)map[string]any{args,_:=json.Marshal(call.Arguments);return map[string]any{"id":call.ID,"type":"function","function":map[string]any{"name":call.Name,"arguments":string(args)}}}
func anthropicCall(call *Call)map[string]any{return map[string]any{"type":"tool_use","id":call.ID,"name":call.Name,"input":call.Arguments}}
func(s *service) generate(w http.ResponseWriter,r *http.Request,req request){
 ctx,cancel:=context.WithCancel(r.Context());defer cancel();ch:=make(chan generation,8);workerDone:=make(chan struct{})
 go func(){defer close(workerDone);s.produce(ctx,req,ch)}();defer func(){cancel();<-workerDone}()
 id:=newID("chatcmpl_");if req.anthropic{id=newID("msg_")};created:=time.Now().Unix();var text,reason strings.Builder
 content:=[]any{};calls:=[]any{}
 var stream *streamWriter;if req.stream{stream=newStream(w,req,id,created);if err:=stream.start();err!=nil{return}}
 failure:=func(status int,err error){s.failed.Add(1);if stream!=nil{_ = stream.failure(err.Error())}else{apiError(w,status,err.Error())}}
 consume:=func(ev Event)error{
  if err:=ctx.Err();err!=nil{return err}
  if stream!=nil{return stream.feed(ev)}
  if ev.Call!=nil{calls=append(calls,openAICall(ev.Call));content=append(content,anthropicCall(ev.Call))
  }else if ev.Kind=="reasoning"{reason.WriteString(ev.Text);if len(req.tools)>0{content=append(content,map[string]any{"type":"thinking","thinking":ev.Text})}
  }else{text.WriteString(ev.Text);if len(req.tools)>0{content=append(content,map[string]any{"type":"text","text":ev.Text})}}
  return nil
 }
 heartbeat:=time.NewTicker(10*time.Second);defer heartbeat.Stop()
 for{select{
 case <-ctx.Done():failure(504,ctx.Err());return
 case <-heartbeat.C:if stream!=nil{if err:=stream.ping();err!=nil{return}}
 case item,ok:=<-ch:
  if !ok{failure(502,errors.New("missing terminal record"));return}
  if !item.done{if err:=consume(item.event);err!=nil{failure(502,err);return};continue}
  if item.err!=nil{failure(502,item.err);return}
  if err:=ctx.Err();err!=nil{failure(504,err);return}
  for _,ev:=range item.events{if err:=consume(ev);err!=nil{failure(502,err);return}}
  if err:=ctx.Err();err!=nil{failure(504,err);return}
  if stream!=nil{if err:=stream.finish(item.finish,item.tokens);err!=nil{s.failed.Add(1)}else{s.completed.Add(1)};return}
  s.completed.Add(1)
  if req.anthropic{
   if len(req.tools)==0{if reason.Len()>0{content=append(content,map[string]any{"type":"thinking","thinking":reason.String()})};if text.Len()>0{content=append(content,map[string]any{"type":"text","text":text.String()})}}
   stop:="end_turn";if item.finish=="length"{stop="max_tokens"};if len(calls)>0{stop="tool_use"}
   writeJSON(w,200,map[string]any{"id":id,"type":"message","role":"assistant","model":"strata-byte-fixture","content":content,"stop_reason":stop,"stop_sequence":nil,"usage":map[string]int{"input_tokens":len(req.prompt),"output_tokens":item.tokens}})
  }else{
   msg:=map[string]any{"role":"assistant","content":text.String()};if reason.Len()>0{msg["reasoning_content"]=reason.String()};finish:=item.finish
   if len(calls)>0{msg["tool_calls"]=calls;finish="tool_calls";if text.Len()==0{msg["content"]=nil}}
   writeJSON(w,200,map[string]any{"id":id,"object":"chat.completion","created":created,"model":"strata-byte-fixture","choices":[]any{map[string]any{"index":0,"message":msg,"finish_reason":finish}},"usage":map[string]int{"prompt_tokens":len(req.prompt),"completion_tokens":item.tokens,"total_tokens":len(req.prompt)+item.tokens}})
  };return
 }}
}
type streamWriter struct{w http.ResponseWriter;rc *http.ResponseController;req request;id string;created int64;index int;kind string;opened bool;toolIndex int}
func newStream(w http.ResponseWriter,req request,id string,created int64)*streamWriter{return &streamWriter{w:w,rc:http.NewResponseController(w),req:req,id:id,created:created,index:-1}}
func(sw *streamWriter) frame(event string,data any)error{
 _ = sw.rc.SetWriteDeadline(time.Now().Add(15*time.Second));b,err:=json.Marshal(data);if err!=nil{return err}
 if event!=""{if _,err=fmt.Fprintf(sw.w,"event: %s\n",event);err!=nil{return err}};if _,err=fmt.Fprintf(sw.w,"data: %s\n\n",b);err!=nil{return err};return sw.rc.Flush()
}
func(sw *streamWriter) anthropic(kind string,data map[string]any)error{data["type"]=kind;return sw.frame(kind,data)}
func(sw *streamWriter) chunk(delta any,finish any)error{return sw.frame("",map[string]any{"id":sw.id,"object":"chat.completion.chunk","created":sw.created,"model":"strata-byte-fixture","choices":[]any{map[string]any{"index":0,"delta":delta,"finish_reason":finish}}})}
func(sw *streamWriter) start()error{
 sw.w.Header().Set("Content-Type","text/event-stream");sw.w.Header().Set("X-Accel-Buffering","no");sw.w.WriteHeader(200)
 if sw.req.anthropic{return sw.anthropic("message_start",map[string]any{"message":map[string]any{"id":sw.id,"type":"message","role":"assistant","model":"strata-byte-fixture","content":[]any{},"stop_reason":nil,"stop_sequence":nil,"usage":map[string]int{"input_tokens":len(sw.req.prompt),"output_tokens":0}}})};return sw.chunk(map[string]any{"role":"assistant"},nil)
}
func(sw *streamWriter) closeBlock()error{if !sw.opened{return nil};sw.opened=false;return sw.anthropic("content_block_stop",map[string]any{"index":sw.index})}
func(sw *streamWriter) feed(ev Event)error{
 if ev.Call!=nil{return sw.tool(ev.Call)}
 if !sw.req.anthropic{key:="content";if ev.Kind=="reasoning"{key="reasoning_content"};return sw.chunk(map[string]any{key:ev.Text},nil)}
 kind:="text";if ev.Kind=="reasoning"{kind="thinking"}
 if !sw.opened||sw.kind!=kind{if err:=sw.closeBlock();err!=nil{return err};sw.index++;sw.kind=kind;sw.opened=true;if err:=sw.anthropic("content_block_start",map[string]any{"index":sw.index,"content_block":map[string]any{"type":kind,kind:""}});err!=nil{return err}}
 return sw.anthropic("content_block_delta",map[string]any{"index":sw.index,"delta":map[string]any{"type":kind+"_delta",kind:ev.Text}})
}
func(sw *streamWriter) finish(finish string,tokens int)error{
 if sw.req.anthropic{if err:=sw.closeBlock();err!=nil{return err};stop:="end_turn";if finish=="length"{stop="max_tokens"};if sw.toolIndex>0{stop="tool_use"};if err:=sw.anthropic("message_delta",map[string]any{"delta":map[string]any{"stop_reason":stop,"stop_sequence":nil},"usage":map[string]int{"output_tokens":tokens}});err!=nil{return err};return sw.anthropic("message_stop",map[string]any{})}
 if sw.toolIndex>0{finish="tool_calls"}
 if err:=sw.chunk(map[string]any{},finish);err!=nil{return err};_,err:=io.WriteString(sw.w,"data: [DONE]\n\n");if err!=nil{return err};return sw.rc.Flush()
}
func(sw *streamWriter) ping()error{_ = sw.rc.SetWriteDeadline(time.Now().Add(15*time.Second));_,err:=io.WriteString(sw.w,": keepalive\n\n");if err!=nil{return err};return sw.rc.Flush()}
func(sw *streamWriter) failure(message string)error{if sw.req.anthropic{return sw.anthropic("error",map[string]any{"error":map[string]any{"type":"api_error","message":message}})};return sw.frame("",map[string]any{"error":map[string]any{"message":message,"type":"server_error"}})}

// Complete argument payloads are serialized only after the generation transaction commits.
// These fixture event structures are API-specific, not asserted upstream event parity.
func(sw *streamWriter) tool(call *Call)error{
 args,err:=json.Marshal(call.Arguments);if err!=nil{return err}
 if !sw.req.anthropic{
  index:=sw.toolIndex;sw.toolIndex++
  return sw.chunk(map[string]any{"tool_calls":[]any{map[string]any{"index":index,"id":call.ID,"type":"function","function":map[string]any{"name":call.Name,"arguments":string(args)}}}},nil)
 }
 if err=sw.closeBlock();err!=nil{return err};sw.index++;sw.kind="tool_use";sw.opened=true;sw.toolIndex++
 if err=sw.anthropic("content_block_start",map[string]any{"index":sw.index,"content_block":map[string]any{"type":"tool_use","id":call.ID,"name":call.Name,"input":map[string]any{}}});err!=nil{return err}
 if err=sw.anthropic("content_block_delta",map[string]any{"index":sw.index,"delta":map[string]any{"type":"input_json_delta","partial_json":string(args)}});err!=nil{return err}
 return sw.closeBlock()
}

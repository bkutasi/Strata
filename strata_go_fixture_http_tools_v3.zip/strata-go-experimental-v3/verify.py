"""Offline build/test entrypoint. Missing Go is a hard failure, not a skipped success."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    env = {**os.environ, 'GOPROXY': 'off', 'GOSUMDB': 'off', 'GOTOOLCHAIN': 'local'}
    report = {'go_build': 'not_run', 'go_tests': 'not_run', 'go_vet': 'not_run', 'python_support_tests': 'not_run', 'commands': []}
    steps = [[sys.executable, '-m', 'unittest', '-v', 'test_fixture', 'test_launch', 'test_excerpt_oracle']]
    if shutil.which('go'):
        steps += [['go', 'version'], ['gofmt', '-w', *sorted(p.name for p in ROOT.glob('*.go'))], ['go', 'vet', './...'], ['go', 'test', '-race', '-count=1', '-timeout=180s', './...'], ['go', 'build', '-trimpath', '-o', 'strata-go-experimental', '.']]
    else:
        report['blocker'] = 'Go compiler is absent; no binary, Go test result, endpoint result or server RSS measurement can be produced.'
    code = 0
    for command in steps:
        result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
        report['commands'].append({'argv': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        print('$', ' '.join(command))
        print(result.stdout, end='')
        print(result.stderr, end='', file=sys.stderr)
        if command[1:3] == ['-m', 'unittest']:
            report['python_support_tests'] = 'passed' if result.returncode == 0 else 'failed'
        elif command[:2] == ['go', 'vet']:
            report['go_vet'] = 'passed' if result.returncode == 0 else 'failed'
        elif command[:2] == ['go', 'test']:
            report['go_tests'] = 'passed' if result.returncode == 0 else 'failed'
        elif command[:2] == ['go', 'build']:
            report['go_build'] = 'passed' if result.returncode == 0 else 'failed'
        if result.returncode:
            code = result.returncode
            break
    if 'blocker' in report:
        print(report['blocker'], file=sys.stderr)
        code = code or 2
    (ROOT / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
    return code


if __name__ == '__main__':
    raise SystemExit(main())

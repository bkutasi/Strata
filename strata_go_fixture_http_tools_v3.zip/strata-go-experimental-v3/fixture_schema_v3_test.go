package main
import("testing";"strings")
func TestHTTPFixtureSchemaSubset(t *testing.T){
 for _,c:=range []struct{name,schema,args string;status int}{
  {"string",`{"type":"object","properties":{"path":{"type":"string"}},"required":["path"],"additionalProperties":false}`,`{"path":"東京"}`,200},
  {"missing",`{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}`,`{}`,502},
  {"extra",`{"type":"object","properties":{},"additionalProperties":false}`,`{"extra":1}`,502},
  {"enum",`{"type":"object","properties":{"x":{"type":"string","enum":["yes","no"]}}}`,`{"x":"yes"}`,200},
  {"enum-bad",`{"type":"object","properties":{"x":{"type":"string","enum":["yes","no"]}}}`,`{"x":"other"}`,502},
  {"array",`{"type":"object","properties":{"x":{"type":"array","items":{"type":"integer"}}}}`, `{"x":[1,2]}`,200},
  {"array-bad",`{"type":"object","properties":{"x":{"type":"array","items":{"type":"integer"}}}}`, `{"x":[1,"2"]}`,502},
  {"nested",`{"type":"object","properties":{"x":{"type":"object","properties":{"flag":{"type":"boolean"}}}}}`,`{"x":{"flag":true}}`,200},
  {"nested-bad",`{"type":"object","properties":{"x":{"type":"object","properties":{"flag":{"type":"boolean"}}}}}`,`{"x":{"flag":"true"}}`,502},
  {"null",`{"type":"object","properties":{"x":{"type":"null"}}}`,`{"x":null}`,200},
  {"number",`{"type":"object","properties":{"x":{"type":"number"}}}`,`{"x":1.25e100}`,200},
  {"integer-lexical-limit",`{"type":"object","properties":{"x":{"type":"integer"}}}`,`{"x":1.0}`,502},
  {"unknown-keyword",`{"type":"object","oneOf":[]}`,`{}`,400},
  {"bad-required",`{"type":"object","required":["x"]}`,`{}`,400},
  {"duplicate-required",`{"type":"object","properties":{"x":{"type":"string"}},"required":["x","x"]}`,`{}`,400},
  {"bad-properties",`{"type":"object","properties":[]}`,`{}`,400},
  {"bad-items",`{"type":"array","items":false}`,`{}`,400},
  {"bad-additional",`{"type":"object","additionalProperties":{}}`,`{}`,400},
  {"bad-type",`{"type":"object","properties":{"x":{"type":["string","null"]}}}`,`{}`,400},
  {"bad-enum",`{"type":"object","properties":{"x":{"type":"string","enum":[]}}}`,`{}`,400},
 }{t.Run(c.name,func(t *testing.T){for _,anthropic:=range []bool{false,true}{schema:=jsonObject(t,c.schema);req:=fixtureRequest(anthropic,false);tool:=fixtureToolDefinition(anthropic,"read");if anthropic{tool["input_schema"]=schema}else{tool["function"].(map[string]any)["parameters"]=schema};req["tools"]=[]any{tool}
  cfg:=defaultConfig();cfg.Engine="mock";script:=`<tool_call>{"name":"read","arguments":`+c.args+`}</tool_call>`;ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:script}));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=c.status{t.Fatal(status,c.status,body)}
 }})}
}
func TestToolCountAndSchemaDepthBounds(t *testing.T){
 for _,anthropic:=range []bool{false,true}{req:=fixtureRequest(anthropic,false);tools:=[]any{};for i:=0;i<65;i++{tools=append(tools,fixtureToolDefinition(anthropic,strings.Repeat("x",i+1)))};req["tools"]=tools;cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:"ok"}));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=400{t.Fatal(status,body)}}
 schema:=map[string]any{"type":"string"};for i:=0;i<18;i++{schema=map[string]any{"type":"array","items":schema}};if err:=checkSchema(schema,0);err==nil{t.Fatal("schema depth not bounded")}
}

package main

import("bufio";"context";"errors";"fmt";"io";"os";"strconv";"strings";"sync";"testing";"time")
// Helper modes use stdin/stdout events, never sleeps, to control cancellation.
func TestLifecycleHelper(t *testing.T){
 mode:=os.Getenv("STRATA_GO_LIFECYCLE_HELPER");if mode==""{return}
 switch mode{case "ready-error":fmt.Println("ERR cannot load");case "bad-ready":fmt.Println("READY nope stop");case "short-ready":fmt.Println("READY");case "ready-eof":os.Exit(9);case "native-ready":fmt.Println("READY 32768 stop");case "no-stop":fmt.Println("READY 32768 fixture-byte-v1");default:fmt.Println("READY 32768 stop fixture-byte-v1")}
 turns:=0;scan:=bufio.NewScanner(os.Stdin)
 for scan.Scan(){line:=scan.Text();if line=="QUIT"{if mode=="ignore-quit"{ticker:=time.NewTicker(time.Hour);defer ticker.Stop();for range ticker.C{}};os.Exit(0)}
  if line=="STOP"{if mode=="bad-stop"{fmt.Println("ERR stop refused")}else{fmt.Println("DONE finish=stop")};continue}
  if !strings.HasPrefix(line,"GEN "){fmt.Println("ERR unexpected command");continue};turns++
  switch mode{
  case "eof":fmt.Println("T 65");os.Exit(7)
  case "error":fmt.Println("ERR nonfinite logits")
  case "invalid":fmt.Println("T not-a-number")
  case "out-of-range":fmt.Println("T 256")
  case "negative":fmt.Println("T -1")
  case "unknown":fmt.Println("MYSTERY")
  case "over-cap":fmt.Println("T 65");fmt.Println("T 66");fmt.Println("DONE finish=stop")
  case "cancel","bad-stop","no-stop","close":if turns==1{fmt.Println("T 65")}else{fmt.Println("T 66");fmt.Println("DONE finish=stop")}
  case "bad-finish":fmt.Println("DONE finish=error");case "length":fmt.Println("T 65");fmt.Println("DONE finish=length")
  default:
   fields:=strings.Fields(line);id:=65;if len(fields)>2{first:=strings.Split(fields[2],",")[0];if n,err:=strconv.Atoi(first);err==nil{id=n}}
   fmt.Printf("T %d\n",id);fmt.Println("DONE finish=stop")
  }
 };os.Exit(0)
}
func lifecycleEngine(t *testing.T,mode string)*WireEngine{
 t.Helper();t.Setenv("STRATA_GO_LIFECYCLE_HELPER",mode)
 e,err:=startWire(context.Background(),[]string{os.Args[0],"-test.run=^TestLifecycleHelper$"},5*time.Second);if err!=nil{t.Fatal(err)}
 t.Cleanup(func(){_ = e.Close()});return e
}
func receiveError(t *testing.T,ch <-chan error)error{t.Helper();select{case err:=<-ch:return err;case <-time.After(10*time.Second):t.Fatal("event deadline exceeded");return nil}}
func TestWireCancellationDrainAndReuse(t *testing.T){
 e:=lifecycleEngine(t,"cancel");ctx,cancel:=context.WithCancel(context.Background());defer cancel()
 finish,err:=e.Generate(ctx,[]int{1},8,func(int)error{cancel();return nil})
 if finish!=""||!errors.Is(err,context.Canceled){t.Fatal(finish,err)}
 got:=0;finish,err=e.Generate(context.Background(),[]int{1},8,func(id int)error{got=id;return nil})
 if err!=nil||finish!="stop"||got!=66{t.Fatal(finish,err,got)}
}
func TestWireCallbackFailureDrains(t *testing.T){
 e:=lifecycleEngine(t,"cancel");sentinel:=errors.New("consumer stopped")
 if _,err:=e.Generate(context.Background(),nil,8,func(int)error{return sentinel});!errors.Is(err,sentinel){t.Fatal(err)}
 got:=0;if _,err:=e.Generate(context.Background(),nil,8,func(id int)error{got=id;return nil});err!=nil||got!=66{t.Fatal(got,err)}
}
func TestWireCancellationWithoutStopOrWithBadStop(t *testing.T){
 for _,mode:=range []string{"no-stop","bad-stop"}{t.Run(mode,func(t *testing.T){e:=lifecycleEngine(t,mode);ctx,cancel:=context.WithCancel(context.Background());defer cancel()
  if _,err:=e.Generate(ctx,nil,8,func(int)error{cancel();return nil});!errors.Is(err,context.Canceled){t.Fatal(err)}
  if _,err:=e.Generate(context.Background(),nil,8,func(int)error{return nil});!errors.Is(err,ErrEngineClosed){t.Fatal(err)}
 })}
}
func TestWireErrorEOFAndInvalidRecords(t *testing.T){
 for _,mode:=range []string{"eof","error","invalid","out-of-range","negative","unknown","over-cap","bad-finish"}{t.Run(mode,func(t *testing.T){e:=lifecycleEngine(t,mode)
  _,err:=e.Generate(context.Background(),[]int{1},1,func(int)error{return nil});if err==nil{t.Fatal("failure treated as success")}
  if mode=="eof"{if !errors.Is(err,io.EOF){t.Fatal(err)} // EOF is retained even when the process exit error is joined.
   if e.waitErr==nil{t.Fatal("lost child exit status")}}
  select{case <-e.waitDone:default:t.Fatal("child not reaped")};select{case <-e.readDone:default:t.Fatal("reader not stopped")}
  if _,err=e.Generate(context.Background(),nil,1,func(int)error{return nil});!errors.Is(err,ErrEngineClosed){t.Fatal(err)}
 })}
}
func TestWireReadinessFailures(t *testing.T){for _,mode:=range []string{"ready-error","bad-ready","short-ready","ready-eof","native-ready"}{t.Run(mode,func(t *testing.T){t.Setenv("STRATA_GO_LIFECYCLE_HELPER",mode);if e,err:=startWire(context.Background(),[]string{os.Args[0],"-test.run=^TestLifecycleHelper$"},5*time.Second);err==nil{_ = e.Close();t.Fatal("bad readiness accepted")}})}}
func TestWireConcurrentTransactions(t *testing.T){
 e:=lifecycleEngine(t,"normal");start:=make(chan struct{});results:=make(chan error,16);var wg sync.WaitGroup
 for i:=0;i<16;i++{wg.Add(1);go func(id int){defer wg.Done();<-start;got:=-1;finish,err:=e.Generate(context.Background(),[]int{id},8,func(token int)error{got=token;return nil});if err==nil&&(got!=id||finish!="stop"){err=fmt.Errorf("transaction %d got %d finish %s",id,got,finish)};results<-err}(i)}
 close(start);wg.Wait();close(results);for err:=range results{if err!=nil{t.Fatal(err)}}
}
func TestWireWaitingGenerationCancellation(t *testing.T){
 e:=lifecycleEngine(t,"normal");entered:=make(chan struct{});release:=make(chan struct{});var once sync.Once;defer once.Do(func(){close(release)})
 first:=make(chan error,1);go func(){_,err:=e.Generate(context.Background(),[]int{1},8,func(int)error{close(entered);<-release;return nil});first<-err}()
 select{case <-entered:case <-time.After(10*time.Second):t.Fatal("first generation never entered")}
 ctx,cancel:=context.WithCancel(context.Background());second:=make(chan error,1);started:=make(chan struct{})
 go func(){close(started);_,err:=e.Generate(ctx,[]int{2},8,func(int)error{return errors.New("waiter emitted")});second<-err}();<-started;cancel()
 if err:=receiveError(t,second);!errors.Is(err,context.Canceled){t.Fatal(err)};once.Do(func(){close(release)});if err:=receiveError(t,first);err!=nil{t.Fatal(err)}
}
func TestWireConcurrentCloseDuringRead(t *testing.T){
 e:=lifecycleEngine(t,"close");entered:=make(chan struct{});result:=make(chan error,1)
 go func(){_,err:=e.Generate(context.Background(),nil,8,func(int)error{close(entered);return nil});result<-err}()
 select{case <-entered:case <-time.After(10*time.Second):t.Fatal("missing token event")}
 var wg sync.WaitGroup;for i:=0;i<4;i++{wg.Add(1);go func(){defer wg.Done();_ = e.Close()}()};wg.Wait()
 if err:=receiveError(t,result);err==nil{t.Fatal("close treated as successful generation")}
 select{case <-e.waitDone:default:t.Fatal("child not reaped")};select{case <-e.readDone:default:t.Fatal("reader not stopped")}
}
func TestWireValidationAndLength(t *testing.T){
 e:=lifecycleEngine(t,"length")
 for _,c:=range []struct{ids []int;cap int;emit func(int)error}{{nil,0,func(int)error{return nil}},{[]int{256},1,func(int)error{return nil}},{nil,1,nil},{nil,32768,func(int)error{return nil}},{nil,int(^uint(0)>>1),func(int)error{return nil}}}{if _,err:=e.Generate(context.Background(),c.ids,c.cap,c.emit);err==nil{t.Fatal("invalid request accepted")}}
 if finish,err:=e.Generate(context.Background(),nil,1,func(int)error{return nil});err!=nil||finish!="length"{t.Fatal(finish,err)}
 ctx,cancel:=context.WithCancel(context.Background());cancel();if _,err:=e.Generate(ctx,nil,1,func(int)error{return nil});!errors.Is(err,context.Canceled){t.Fatal(err)}
 if _,err:=startWire(ctx,[]string{"must-not-start"},time.Second);!errors.Is(err,context.Canceled){t.Fatal(err)}
}
func TestFIFOStopWakesPending(t *testing.T){q:=&FIFO{max:4};release,err:=q.Acquire(context.Background());if err!=nil{t.Fatal(err)};defer release();results:=make(chan error,3)
 for i:=0;i<3;i++{go func(){r,err:=q.Acquire(context.Background());if err==nil{r()};results<-err}()};waitQueued(t,q,3);q.Stop();q.Stop()
 for i:=0;i<3;i++{if err:=receiveError(t,results);!errors.Is(err,ErrQueueStopped){t.Fatal(err)}};if _,n:=q.State();n!=0{t.Fatal(n)}
}
func TestByteEngineInvalidInputs(t *testing.T){e:=&ByteEngine{Script:"x"};for _,cap:=range []int{-1,0}{if _,err:=e.Generate(context.Background(),nil,cap,func(int)error{return nil});err==nil{t.Fatal(cap)}};if _,err:=e.Generate(context.Background(),nil,1,nil);err==nil{t.Fatal("nil callback")}}

func TestFIFOArrivalOrder(t *testing.T){
 q:=&FIFO{max:3};release,err:=q.Acquire(context.Background());if err!=nil{t.Fatal(err)}
 order:=make(chan int,3);results:=make(chan error,3)
 for i:=0;i<3;i++{go func(id int){r,err:=q.Acquire(context.Background());if err==nil{order<-id;r()};results<-err}(i);waitQueued(t,q,i+1)}
 release();for i:=0;i<3;i++{select{case got:=<-order:if got!=i{t.Fatal(got,i)};case <-time.After(10*time.Second):t.Fatal("queue event deadline")}}
 for i:=0;i<3;i++{if err:=receiveError(t,results);err!=nil{t.Fatal(err)}}
}

func TestDoneFinishCases(t *testing.T){
 for _,c:=range []struct{line,want string;valid bool}{{"","",false},{"DONEbad","",false},{"DONE","stop",true},{"DONE finish=stop","stop",true},{"DONE length","length",true},{"DONE finish=length","length",true},{"DONE finish=error","",false},{"DONE finish=stop finish=length","",false}}{got,err:=doneFinish(c.line);if (err==nil)!=c.valid||got!=c.want{t.Fatal(c,got,err)}}
}

func TestWireIdleTimeoutFailsClosed(t *testing.T){
 e:=lifecycleEngine(t,"close");e.timeout=20*time.Millisecond
 if _,err:=e.Generate(context.Background(),nil,8,func(int)error{return nil});!errors.Is(err,context.DeadlineExceeded){t.Fatal(err)}
 select{case <-e.waitDone:default:t.Fatal("timeout left child running")}
}
func TestWireEscalatesAndReapsUncooperativeChild(t *testing.T){
 e:=lifecycleEngine(t,"ignore-quit");if err:=e.Close();err==nil{t.Fatal("expected killed child exit status")}
 select{case <-e.waitDone:default:t.Fatal("child not reaped")};select{case <-e.readDone:default:t.Fatal("reader not closed")}
}
type deadlineTestPipe struct{deadlineErr error;writeErr error;writes int}
func(p *deadlineTestPipe) SetWriteDeadline(time.Time)error{return p.deadlineErr}
func(p *deadlineTestPipe) Write(b []byte)(int,error){p.writes++;if p.writeErr!=nil{return 0,p.writeErr};return len(b),nil}
func(p *deadlineTestPipe) Close()error{return nil}
func TestWireWriteFailures(t *testing.T){
 sentinel:=errors.New("pipe failure")
 for _,p:=range []*deadlineTestPipe{{deadlineErr:sentinel},{writeErr:sentinel}}{e:=&WireEngine{in:p};if err:=e.send("GEN 1 1");!errors.Is(err,sentinel){t.Fatal(err)}}
}

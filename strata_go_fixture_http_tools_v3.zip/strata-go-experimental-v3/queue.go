package main

import("context";"errors";"sync")
var ErrQueueStopped=errors.New("server stopping")
type waiter struct {ready chan struct{};granted bool;err error}
type FIFO struct {mu sync.Mutex;active bool;pending []*waiter;max int;closed bool;changed chan struct{}}
// changed is a state-notification channel, not a timer or test-only callback.
func(q *FIFO) notifyLocked(){if q.changed!=nil{close(q.changed)};q.changed=make(chan struct{})}
func(q *FIFO) snapshot()(bool,int,<-chan struct{}){q.mu.Lock();defer q.mu.Unlock();if q.changed==nil{q.changed=make(chan struct{})};return q.active,len(q.pending),q.changed}
func(q *FIFO) Acquire(ctx context.Context)(func(),error){
 if err:=ctx.Err();err!=nil{return nil,err}
 q.mu.Lock();if q.closed{q.mu.Unlock();return nil,ErrQueueStopped}
 if !q.active{q.active=true;q.notifyLocked();q.mu.Unlock();return q.Release,nil}
 if len(q.pending)>=q.max{q.mu.Unlock();return nil,errors.New("queue full")}
 w:=&waiter{ready:make(chan struct{})};q.pending=append(q.pending,w);q.notifyLocked();q.mu.Unlock()
 select {
 case <-w.ready:
  if w.err!=nil{return nil,w.err};if err:=ctx.Err();err!=nil{q.Release();return nil,err};return q.Release,nil
 case <-ctx.Done():
  q.mu.Lock();granted:=w.granted
  if !granted{for i,p:=range q.pending{if p==w{q.pending=append(q.pending[:i],q.pending[i+1:]...);q.notifyLocked();break}}}
  q.mu.Unlock();if granted{q.Release()};return nil,ctx.Err()
 }
}
func(q *FIFO) Release(){q.mu.Lock();defer q.mu.Unlock();if len(q.pending)==0{q.active=false;q.notifyLocked();return};w:=q.pending[0];q.pending=q.pending[1:];w.granted=true;close(w.ready);q.notifyLocked()}
func(q *FIFO) State()(bool,int){q.mu.Lock();defer q.mu.Unlock();return q.active,len(q.pending)}
func(q *FIFO) Stop(){q.mu.Lock();defer q.mu.Unlock();if q.closed{return};q.closed=true;for _,w:=range q.pending{w.err=ErrQueueStopped;close(w.ready)};q.pending=nil;q.notifyLocked()}

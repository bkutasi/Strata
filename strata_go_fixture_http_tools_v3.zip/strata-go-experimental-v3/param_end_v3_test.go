package main
import("testing";"strings")
func TestConfirmedParameterFollowerRegression(t *testing.T){
 for _,follower:=range []string{""," ","</fun","<para","<parameter=","</function>","<parameter=x>"}{
  text:="x</parameter>"+follower
  for _,final:=range []bool{false,true}{want:=-2;if final||strings.HasPrefix(strings.TrimSpace(follower),"</function>")||strings.HasPrefix(strings.TrimSpace(follower),"<parameter="){want=1};if got:=parameterEnd(text,final);got!=want{t.Fatalf("%q final=%v got=%d want=%d",text,final,got,want)}}
  if strings.TrimSpace(follower)=="<parameter="||follower=="<parameter=x>"{continue}
  call,err:=parseToolCall("<function=read><parameter=x>"+text,nil);if err!=nil||call.Arguments["x"]!="x"{t.Fatal(follower,call,err)}
 }
 for _,follower:=range []string{"</fun","<para"}{
  p:=NewParser(false);events,err:=p.Feed("<tool_call><function=read><parameter=x>x</parameter>"+follower,true)
  if err==nil{t.Fatal("incomplete stream accepted",follower)};for _,ev:=range events{if ev.Call!=nil{t.Fatal("incomplete call emitted")}}
 }
}

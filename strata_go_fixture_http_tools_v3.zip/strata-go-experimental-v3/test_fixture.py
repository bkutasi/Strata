"""These tests exercise ONLY the Python protocol fixture, never the Go implementation."""
import os
from pathlib import Path
import selectors
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent


class Child:
    def __init__(self, *args):
        self.p = subprocess.Popen([sys.executable, '-u', str(ROOT / 'fake_engine.py'), *args], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.sel = selectors.DefaultSelector()
        self.sel.register(self.p.stdout, selectors.EVENT_READ)
        self.pending = bytearray()
        assert self.line().startswith('READY ')

    def line(self):
        while b'\n' not in self.pending:
            if not self.sel.select(3):
                raise AssertionError('fixture response deadline exceeded')
            chunk = os.read(self.p.stdout.fileno(), 4096)
            if not chunk:
                raise EOFError('fixture stdout closed')
            self.pending.extend(chunk)
        raw, _, rest = self.pending.partition(b'\n')
        self.pending = bytearray(rest)
        return raw.decode('utf-8')

    def send(self, text):
        self.p.stdin.write((text + '\n').encode())
        self.p.stdin.flush()

    def generation(self, cap=100):
        self.send(f'GEN {cap} 1,2,3')
        tokens = bytearray()
        while True:
            line = self.line()
            if line.startswith('DONE'):
                return bytes(tokens), line
            if line.startswith('ERR'):
                return bytes(tokens), line
            assert line.startswith('T '), line
            tokens.append(int(line[2:]))

    def close(self):
        try:
            if self.p.poll() is None:
                try:
                    self.send('QUIT')
                except BrokenPipeError:
                    pass
                self.p.wait(timeout=3)
        finally:
            if self.p.poll() is None:
                self.p.kill()
                self.p.wait(timeout=3)
            self.sel.close()
            for f in (self.p.stdin, self.p.stdout, self.p.stderr):
                f.close()


class FixtureTests(unittest.TestCase):
    def child(self, *args):
        child = Child(*args)
        self.addCleanup(child.close)
        return child

    def test_generation(self):
        self.assertEqual(self.child('--script', 'hello').generation(), (b'hello', 'DONE finish=stop'))

    def test_unicode_bytes(self):
        text = 'Grüße 東京 a\u0301'
        self.assertEqual(self.child('--script', text).generation()[0].decode(), text)

    def test_output_cap(self):
        self.assertEqual(self.child('--script', 'abcdef').generation(3), (b'abc', 'DONE finish=length'))

    def test_sequential_requests(self):
        c = self.child('--script', 'ok')
        for _ in range(30):
            self.assertEqual(c.generation(), (b'ok', 'DONE finish=stop'))

    def test_invalid_command(self):
        c = self.child()
        c.send('BOGUS')
        self.assertEqual(c.line(), 'ERR malformed fixture GEN')

    def test_invalid_prompt_token(self):
        c = self.child()
        c.send('GEN 4 999')
        self.assertEqual(c.line(), 'ERR malformed fixture GEN')

    def test_error(self):
        self.assertEqual(self.child('--fault', 'error').generation()[1], 'ERR fixture failure')

    def test_nonfinite(self):
        self.assertEqual(self.child('--fault', 'nonfinite').generation()[1], 'ERR nonfinite logits')

    def test_crash_eof(self):
        c = self.child('--fault', 'eof')
        with self.assertRaises(EOFError):
            c.generation()
        self.assertEqual(c.p.wait(timeout=3), 7)

    def test_stop(self):
        c = self.child('--script', 'a' * 1000, '--hold-after-first')
        c.send('GEN 1000 1')
        self.assertTrue(c.line().startswith('T '))
        c.send('STOP')
        while True:
            line = c.line()
            if line.startswith('DONE'):
                self.assertEqual(line, 'DONE finish=stop')
                break

    def test_quit_during_generation(self):
        c = self.child('--script', 'a' * 1000, '--hold-after-first')
        c.send('GEN 1000 1')
        self.assertTrue(c.line().startswith('T '))
        c.send('QUIT')
        self.assertEqual(c.p.wait(timeout=3), 0)

    def test_stall_cancellation(self):
        c = self.child('--fault', 'stall')
        c.send('GEN 4 1')
        c.send('STOP')
        self.assertEqual(c.line(), 'DONE finish=stop')


if __name__ == '__main__':
    unittest.main(verbosity=2)

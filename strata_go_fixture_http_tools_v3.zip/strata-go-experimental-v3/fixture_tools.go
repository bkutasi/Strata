package main

import (
 "encoding/json"
 "errors"
 "fmt"
 "regexp"
 "strings"
)

var fixtureName=regexp.MustCompile(`^[A-Za-z0-9_.-]{1,64}$`)
type fixtureTool struct {Name string `json:"name"`;Description string `json:"description,omitempty"`;Parameters map[string]any `json:"parameters"`}
type fixtureTurn struct {Role string `json:"role"`;Content string `json:"content,omitempty"`;Calls []*Call `json:"tool_calls,omitempty"`;ResultID string `json:"tool_call_id,omitempty"`;IsError bool `json:"is_error,omitempty"`}
func object(v any,where string)(map[string]any,error){m,ok:=v.(map[string]any);if !ok||m==nil{return nil,fmt.Errorf("%s must be an object",where)};return m,nil}
func fields(m map[string]any,allowed ...string)error{for k:=range m{found:=false;for _,a:=range allowed{if k==a{found=true;break}};if !found{return fmt.Errorf("unsupported field %q",k)}};return nil}
func stringField(m map[string]any,key string,required bool)(string,error){v,ok:=m[key];if !ok&&!required{return "",nil};s,ok:=v.(string);if !ok{return "",fmt.Errorf("%s must be a string",key)};return s,nil}
func validID(s string)bool{return len(s)>0&&len(s)<=128&&!strings.ContainsAny(s,"\r\n\x00")}
// Deliberately small JSON Schema subset. Unsupported keywords fail, not silently disappear.
func checkSchema(s map[string]any,depth int)error{
 if depth>16{return errors.New("tool schema exceeds depth 16")}
 if err:=fields(s,"type","description","properties","required","additionalProperties","items","enum");err!=nil{return err}
 kind,err:=stringField(s,"type",true);if err!=nil{return err}
 switch kind{case "object","array","string","number","integer","boolean","null":default:return errors.New("unsupported schema type")}
 if _,err=stringField(s,"description",false);err!=nil{return err}
 props:=map[string]any{}
 if v,ok:=s["properties"];ok{if kind!="object"{return errors.New("properties requires object type")};props,err=object(v,"properties");if err!=nil{return err};for _,v:=range props{child,err:=object(v,"property schema");if err!=nil{return err};if err=checkSchema(child,depth+1);err!=nil{return err}}}
 if v,ok:=s["required"];ok{if kind!="object"{return errors.New("required requires object type")};list,ok:=v.([]any);if !ok{return errors.New("required must be an array")};seen:=map[string]bool{};for _,v:=range list{name,ok:=v.(string);if !ok||seen[name]{return errors.New("required names must be unique strings")};if _,ok=props[name];!ok{return errors.New("required property has no schema")};seen[name]=true}}
 if v,ok:=s["additionalProperties"];ok{if kind!="object"{return errors.New("additionalProperties requires object type")};if _,ok=v.(bool);!ok{return errors.New("additionalProperties supports boolean only")}}
 if v,ok:=s["items"];ok{if kind!="array"{return errors.New("items requires array type")};child,err:=object(v,"items");if err!=nil{return err};if err=checkSchema(child,depth+1);err!=nil{return err}}
 if v,ok:=s["enum"];ok{list,ok:=v.([]any);if !ok||len(list)==0{return errors.New("enum must be nonempty array")}}
 return nil
}
func validateValue(v any,s map[string]any,depth int)error{
 if depth>32{return errors.New("tool arguments exceed depth 32")}
 kind,_:=s["type"].(string);valid:=false
 switch kind{
 case "object":_,valid=v.(map[string]any)
 case "array":_,valid=v.([]any)
 case "string":_,valid=v.(string)
 case "boolean":_,valid=v.(bool)
 case "null":valid=v==nil
 case "number","integer":n,ok:=v.(json.Number);valid=ok;if ok&&kind=="integer"{valid=!strings.ContainsAny(string(n),".eE")}
 }
 if !valid{return fmt.Errorf("tool argument does not match type %s",kind)}
 if list,ok:=s["enum"].([]any);ok{data,_:=json.Marshal(v);found:=false;for _,item:=range list{b,_:=json.Marshal(item);if string(b)==string(data){found=true;break}};if !found{return errors.New("tool argument not in enum")}}
 if m,ok:=v.(map[string]any);ok{
  props,_:=s["properties"].(map[string]any);required,_:=s["required"].([]any)
  for _,key:=range required{if _,ok:=m[key.(string)];!ok{return fmt.Errorf("missing required tool argument %s",key)}}
  for name,value:=range m{if child,ok:=props[name].(map[string]any);ok{if err:=validateValue(value,child,depth+1);err!=nil{return fmt.Errorf("argument %s: %w",name,err)}}else if additional,ok:=s["additionalProperties"].(bool);ok&&!additional{return fmt.Errorf("undeclared tool argument %s",name)}}
 }
 if list,ok:=v.([]any);ok{if child,ok:=s["items"].(map[string]any);ok{for _,item:=range list{if err:=validateValue(item,child,depth+1);err!=nil{return err}}}}
 return nil
}
func normalizeTools(raw map[string]any,anthropic bool)([]fixtureTool,map[string]map[string]any,string,string,error){
 tools:=[]fixtureTool{};schemas:=map[string]map[string]any{};kind,name:="auto",""
 if v,ok:=raw["tools"];ok{
  list,ok:=v.([]any);if !ok||len(list)==0||len(list)>64{return nil,nil,"","",errors.New("tools must contain 1..64 supported definitions")}
  for _,item:=range list{
   tool,err:=object(item,"tool");if err!=nil{return nil,nil,"","",err};definition:=tool
   if !anthropic{if err=fields(tool,"type","function");err!=nil{return nil,nil,"","",err};if tool["type"]!="function"{return nil,nil,"","",errors.New("only function tools are supported")};definition,err=object(tool["function"],"function");if err!=nil{return nil,nil,"","",err}}
   schemaKey:="parameters";if anthropic{schemaKey="input_schema"}
   if err=fields(definition,"name","description",schemaKey);err!=nil{return nil,nil,"","",err}
   n,err:=stringField(definition,"name",true);if err!=nil||!fixtureName.MatchString(n){return nil,nil,"","",errors.New("tool name must match [A-Za-z0-9_.-]{1,64}")};if _,exists:=schemas[n];exists{return nil,nil,"","",errors.New("duplicate tool name")}
   desc,err:=stringField(definition,"description",false);if err!=nil{return nil,nil,"","",err}
   params,err:=object(definition[schemaKey],schemaKey);if err!=nil{return nil,nil,"","",err};if params["type"]!="object"{return nil,nil,"","",errors.New("root tool schema must have type object")};if err=checkSchema(params,0);err!=nil{return nil,nil,"","",err}
   tools=append(tools,fixtureTool{n,desc,params});schemas[n]=map[string]any{"parameters":params}
  }
 }
 if choice,ok:=raw["tool_choice"];ok{
  if anthropic{
   m,err:=object(choice,"tool_choice");if err!=nil{return nil,nil,"","",err};if err=fields(m,"type","name");err!=nil{return nil,nil,"","",err}
   t,err:=stringField(m,"type",true);if err!=nil{return nil,nil,"","",err};switch t{case "auto","none":kind=t;case "any":kind="required";case "tool":kind="named";name,err=stringField(m,"name",true);if err!=nil{return nil,nil,"","",err};default:return nil,nil,"","",errors.New("unsupported Anthropic tool_choice")}
   if kind!="named"{if _,ok:=m["name"];ok{return nil,nil,"","",errors.New("name only allowed for named tool choice")}}
  }else if t,ok:=choice.(string);ok{switch t{case "auto","none","required":kind=t;default:return nil,nil,"","",errors.New("unsupported OpenAI tool_choice")}
  }else{
   m,err:=object(choice,"tool_choice");if err!=nil{return nil,nil,"","",err};if err=fields(m,"type","function","name");err!=nil{return nil,nil,"","",err};if m["type"]!="function"{return nil,nil,"","",errors.New("named OpenAI choice requires type function")}
   if fn,ok:=m["function"];ok{if _,both:=m["name"];both{return nil,nil,"","",errors.New("ambiguous named tool choice")};f,err:=object(fn,"choice function");if err!=nil{return nil,nil,"","",err};if err=fields(f,"name");err!=nil{return nil,nil,"","",err};name,err=stringField(f,"name",true);if err!=nil{return nil,nil,"","",err}
   }else{name,err=stringField(m,"name",true);if err!=nil{return nil,nil,"","",err}};kind="named"
  }
 }
 if (kind=="required"||kind=="named")&&len(tools)==0{return nil,nil,"","",errors.New("required/named choice requires tools")}
 if kind=="named"{if _,ok:=schemas[name];!ok{return nil,nil,"","",errors.New("named tool choice is undeclared")}}
 return tools,schemas,kind,name,nil
}
func validateCall(call *Call,schemas map[string]map[string]any)error{
 schema,ok:=schemas[call.Name];if !ok{return errors.New("undeclared tool call")};params,_:=schema["parameters"].(map[string]any);return validateValue(call.Arguments,params,0)
}
// Normalize history into a synthetic, API-independent fixture transcript.
func fixtureHistory(raw map[string]any,anthropic bool,schemas map[string]map[string]any)([]fixtureTurn,error){
 turns:=[]fixtureTurn{};pending:=map[string]bool{};used:=map[string]bool{}
 if system,ok:=raw["system"];ok{if !anthropic{return nil,errors.New("system is Anthropic-only")};text,ok:=system.(string);if !ok{return nil,errors.New("system must be a string")};turns=append(turns,fixtureTurn{Role:"system",Content:text})}
 list,ok:=raw["messages"].([]any);if !ok||len(list)==0{return nil,errors.New("messages must be a nonempty array")}
 addCall:=func(call *Call)error{if !validID(call.ID)||used[call.ID]{return errors.New("tool call IDs must be nonempty and unique")};if err:=validateCall(call,schemas);err!=nil{return err};used[call.ID]=true;pending[call.ID]=true;return nil}
 addResult:=func(id string)error{if !pending[id]{return errors.New("orphan or duplicate tool result")};delete(pending,id);return nil}
 for _,item:=range list{
  m,err:=object(item,"message");if err!=nil{return nil,err};role,err:=stringField(m,"role",true);if err!=nil{return nil,err}
  if !anthropic{
   if err=fields(m,"role","content","tool_calls","tool_call_id");err!=nil{return nil,err}
   if role!="system"&&role!="user"&&role!="assistant"&&role!="tool"{return nil,errors.New("unsupported message role")}
   if role!="tool"&&len(pending)>0{return nil,errors.New("tool results must resolve pending calls before another message")}
   turn:=fixtureTurn{Role:role}
   if role=="tool"{if _,ok:=m["tool_calls"];ok{return nil,errors.New("tool result cannot contain calls")};id,err:=stringField(m,"tool_call_id",true);if err!=nil{return nil,err};if err=addResult(id);err!=nil{return nil,err};turn.ResultID=id
   }else if _,ok:=m["tool_call_id"];ok{return nil,errors.New("tool_call_id only allowed on tool results")}
   if calls,ok:=m["tool_calls"];ok{
    if role!="assistant"{return nil,errors.New("tool_calls only allowed on assistant")};calls,ok:=calls.([]any);if !ok||len(calls)==0||len(calls)>64{return nil,errors.New("tool_calls must contain 1..64 calls")}
    for _,value:=range calls{c,err:=object(value,"tool call");if err!=nil{return nil,err};if err=fields(c,"id","type","function");err!=nil{return nil,err};if c["type"]!="function"{return nil,errors.New("only function calls supported")};id,err:=stringField(c,"id",true);if err!=nil{return nil,err};fn,err:=object(c["function"],"call function");if err!=nil{return nil,err};if err=fields(fn,"name","arguments");err!=nil{return nil,err};name,err:=stringField(fn,"name",true);if err!=nil{return nil,err};encoded,err:=stringField(fn,"arguments",true);if err!=nil{return nil,err};args,err:=decodeToolJSON(encoded);if err!=nil{return nil,err};obj,err:=object(args,"arguments");if err!=nil{return nil,err};call:=&Call{ID:id,Name:name,Arguments:obj};if err=addCall(call);err!=nil{return nil,err};turn.Calls=append(turn.Calls,call)}
   }
   if value,ok:=m["content"];ok&&value!=nil{text,ok:=value.(string);if !ok{return nil,errors.New("OpenAI fixture content must be a string")};turn.Content=text
   }else if role!="assistant"||len(turn.Calls)==0{return nil,errors.New("content must be a string unless assistant has tool calls")}
   turns=append(turns,turn);continue
  }
  if err=fields(m,"role","content");err!=nil{return nil,err};if role!="user"&&role!="assistant"&&role!="system"{return nil,errors.New("unsupported Anthropic fixture role")}
  if text,ok:=m["content"].(string);ok{if len(pending)>0{return nil,errors.New("pending tool calls need tool_result blocks")};turns=append(turns,fixtureTurn{Role:role,Content:text});continue}
  blocks,ok:=m["content"].([]any);if !ok||len(blocks)==0{return nil,errors.New("Anthropic content must be string or nonempty supported blocks")}
  if role=="assistant"&&len(pending)>0{return nil,errors.New("pending calls need results")}
  for _,value:=range blocks{
   block,err:=object(value,"content block");if err!=nil{return nil,err};kind,err:=stringField(block,"type",true);if err!=nil{return nil,err}
   switch kind{
   case "text":if err=fields(block,"type","text");err!=nil{return nil,err};if role!="assistant"&&len(pending)>0{return nil,errors.New("tool results must precede user text")};text,err:=stringField(block,"text",true);if err!=nil{return nil,err};turns=append(turns,fixtureTurn{Role:role,Content:text})
   case "tool_use":if role!="assistant"{return nil,errors.New("tool_use requires assistant")};if err=fields(block,"type","id","name","input");err!=nil{return nil,err};id,err:=stringField(block,"id",true);if err!=nil{return nil,err};name,err:=stringField(block,"name",true);if err!=nil{return nil,err};args,err:=object(block["input"],"input");if err!=nil{return nil,err};call:=&Call{ID:id,Name:name,Arguments:args};if err=addCall(call);err!=nil{return nil,err};turns=append(turns,fixtureTurn{Role:role,Calls:[]*Call{call}})
   case "tool_result":if role!="user"{return nil,errors.New("tool_result requires user")};if err=fields(block,"type","tool_use_id","content","is_error");err!=nil{return nil,err};id,err:=stringField(block,"tool_use_id",true);if err!=nil{return nil,err};if err=addResult(id);err!=nil{return nil,err};text,err:=stringField(block,"content",true);if err!=nil{return nil,err};isError:=false;if value,ok:=block["is_error"];ok{var valid bool;isError,valid=value.(bool);if !valid{return nil,errors.New("is_error must be boolean")}};turns=append(turns,fixtureTurn{Role:"tool",ResultID:id,Content:text,IsError:isError})
   default:return nil,errors.New("unsupported Anthropic content block")
   }
  }
 }
 if len(pending)>0{return nil,errors.New("conversation has unresolved tool calls")};return turns,nil
}

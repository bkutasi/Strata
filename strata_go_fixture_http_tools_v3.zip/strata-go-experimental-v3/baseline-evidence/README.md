# Strata Go experimental serving components

**Partial source delivery. Not a drop-in Strata replacement. No Go binary was built.**

This directory was reconstructed in an empty sandbox from the supplied handoff and limited browser-visible source. It is not an upstream checkout or patch. No existing Python default was modified. The native inference engine, model packs and original tests are not included.

## What is here

- Standard-library-only Go HTTP source for explicit byte-fixture modes.
- OpenAI-shaped chat and Anthropic-shaped messages, streaming and non-streaming, reasoning separation, fixture count-tokens and existing Anthropic path aliases.
- Single-sequence line bridge with READY, GEN, T, DONE, ERR, STOP and QUIT handling. It can launch a real subprocess, but accepts **byte fixture tokens only**. Do not point it at a model engine.
- Incremental UTF-8 decoder, buffered reasoning/tool parser and standalone BPE merge primitive. The HTTP fixture rejects tool requests; the parser is an independently testable component.
- FIFO with cancellation, bounded pending inference admission, loopback-only bind, exact listener Host checking, same-origin-only policy, optional hashed constant-time key comparison, request limits and streaming keepalives.
- Go unit/integration test source, a runnable Python fake engine, 12 Python fixture tests, 3 launcher tests, an offline verification runner, a PID-specific Linux memory/endpoint runner and an ephemeral exec launcher.

## Evidence from this sandbox

- Python support tests: **15 passed** (12 protocol-fixture and 3 exec-launcher tests), final run 33.355 seconds. This is not a Go result.
- First run: 1 failure in sequential fixture reuse. Fixed the terminal-state race and strengthened that test to 30 successive generations. Both logs are retained.
- Python source compilation checks: passed for all delivered Python files.
- Go compiler: absent. Go compilation, vet, race tests and HTTP execution: **not run**.
- `verify.py` returns **2**, not success, because the Go compiler is missing.
- `exercise.py` returns **2** because no executable exists. It does not fabricate endpoint or memory results.
- Server RSS, PSS and peak RSS: **not measured**. The approximately 20 MiB idle target is **unverified**.

## Reproducible commands

These commands are supplied for reproducibility, not presented as completed Go runs. They require an already-installed Go 1.22+ toolchain. No module downloads are needed. The race test also requires a working C toolchain.

```sh
python3 verify.py
```

The runner sets `GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local` for every Go command. It runs fixture tests, gofmt, vet, race tests and a build, stopping on failure. It records stdout, stderr and exit codes in `verification.json`.

After a successful build:

```sh
python3 exercise.py --idle-seconds 10
```

This starts only an isolated byte-fixture process on an ephemeral loopback port, exercises actual HTTP, and records `/proc/PID/status` RSS/high-water RSS plus `/proc/PID/smaps_rollup` PSS in KiB. The Python measurement process is not included in those PID figures. It does not test a real model or engine load.

Explicit standalone opt-in launch:

```sh
python3 launch.py --server go --config mock.json
```

The wrapper replaces itself with the Go process using exec; it does not remain resident. Without `--server go` it delegates to `python -m serve.server`, which requires a separate upstream installation. This wrapper is **not** integrated with upstream setup, CLI, desktop or packaging.

Protocol-fixture launch, from this directory:

```sh
./strata-go-experimental --config protocol-fixture.json
```

No default mode silently serves a mock: a mode must be explicit in flags or standalone config. Config fields are specific to this experiment, not compatible with Strata run configs. Unknown fields are rejected.

## Boundaries

Read `REPORT.md` and `compatibility.json` before reusing anything. Production tokenizer/template behavior, Responses, HTTP tools, vision, MCP, images, sessions, replicas, split serving, management ownership, platform process trees and launch integration are missing. Browser UI is excluded. Real-model mode is deliberately unavailable rather than silently substituting byte tokenization.

This does not meet the requested parity acceptance criteria. The delivered source needs a real Go build and test run before it can be called executable or correct.

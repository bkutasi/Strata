# Strata Go implementation evidence and gaps

This is a partial source delivery reconstructed from incomplete inputs, not the requested finished Go replacement. Assumptions are isolated behind explicit fixture modes. No existing installation or Python default was changed.

## Delivered files

- `api.go`: Go implementation source.
- `engine.go`: Go implementation source.
- `main.go`: Go implementation source.
- `parser.go`: Go implementation source.
- `queue.go`: Go implementation source.

- `core_test.go`: 15 Go test functions plus one subprocess-helper entrypoint. All are unrun.
- `fake_engine.py`: deterministic subprocess protocol fixture, not inference.
- `test_fixture.py`: 12 protocol-fixture tests, including 30 sequential requests in one test.
- `test_launch.py`: 3 exec-wrapper tests with temporary fixtures, not a Go executable.
- `launch.py`: explicit standalone selector; Python remains its default. Exec replaces the launcher PID.
- `verify.py`: offline build/test runner, fails rather than silently skipping missing Go.
- `exercise.py`: isolated HTTP and Linux PID-memory runner, not run against Go.
- `mock.json`, `protocol-fixture.json`: standalone fixture configurations, not upstream run configs.
- `README.md`, `compatibility.json`, verification logs and reports.

## What actually ran

Final command: `python3 verify.py`.

- Python support tests: **15 passed in 33.355 seconds**.
- Final verification exit: **2**, because Go is missing. This is intentionally not a successful overall verification.
- `python3 -m py_compile *.py`: exit **0**.
- Direct `GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go test ./...`: exit **127**, `go: command not found`.
- `python3 exercise.py`: exit **2**, executable absent. No HTTP result is claimed.
- Process check after tests found no remaining `fake_engine.py` process.

The first protocol-fixture run failed sequential reuse: `DONE` was visible before the worker thread stopped, so checking thread liveness incorrectly rejected the next request as busy. The fixture now clears its active state before emitting its terminal record. The strengthened test completed 30 successive requests. The first failure and final results are retained, not hidden.

The launcher tests verify Python-default argument forwarding, explicit exec selection, PID replacement and failure without silent fallback. They do not verify upstream CLI or desktop integration.

## Environment and acquisition blockers

- OS: Microsoft Azure Linux 3.0, x86_64, Linux 6.1.158.2-microsoft-standard.
- Python: 3.12.15. GCC 13.2.0 exists; its configured frontends are C, C++ and Fortran, not Go.
- No Go executable, gccgo, cached Go toolchain or local model/tokenizer assets were found in the inspected environment.
- Repository clone returned HTTP 403 with `Request blocked by sandbox policy`.
- Repository archive and Go toolchain archive requests returned HTTP 403, `x-ms-block-reason: url_policy_denied`.
- Browser-visible repository pages supplied limited context, not a complete pinned checkout. No baseline commit, original test suite or exact current behavior was established.
- No further network dependency is introduced. Go module has no third-party dependencies; runner sets `GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local` per command, not globally.

Browser source references inspected:

- https://github.com/Niko1221/Strata/blob/main/AGENTS.md
- https://github.com/Niko1221/Strata/blob/main/serve/server.py
- https://github.com/Niko1221/Strata/blob/main/serve/ready.py

These unpinned browser views are not a source-completeness or parity guarantee. The handoff remains the main behavioral input.

## Compatibility matrix

### Go executable

**not_built**. No Go compiler or cached toolchain; downloads blocked.

### Python default

**untouched**. No upstream checkout modified. Standalone wrapper defaults to Python; forwarding/exec tested with temporary fixtures.

### Native engine bridge

**source_only_partial**. READY/GEN/T/DONE/ERR/STOP/QUIT subset; byte-token protocol fixtures only. No sampling keys, batching, sessions, image variants, restart or full progress grammar.

### Mock engine

**python_fixture_tested_go_source_unrun**. 12 Python fixture tests passed; Go ByteEngine tests not run.

### Production tokenizer

**missing**. Only byte fixture IDs and a standalone BPE merge primitive; no GGUF/vocabulary loading, family pre-tokenization, special-token protection or exact-ID comparison.

### Model templates

**missing**. Deterministic JSON fixture prompt only; no Jinja compatibility or model prompt rendering.

### UTF-8 and output parser

**source_only**. Incremental UTF-8 and reasoning/tool envelope parser. No full quoted-tag/fence/recovery/DSML semantics; HTTP tools rejected.

### Chat completions

**fixture_source_only**. Text messages, stream/nonstream, fixture reasoning, fixture usage and limits. No tools, stop sequences, sampling, logprobs, structured outputs or production equivalence.

### Anthropic messages

**fixture_source_only**. Text-only messages, stream/nonstream, fixture count_tokens and /v1/v1 aliases. No tools, image blocks, budgets, signed thinking or complete Anthropic errors.

### Responses

**missing_explicit_501**. No stateless Responses assembly or event parity.

### Health/models/status/metrics

**fixture_source_only**. Custom fixture data and Prometheus counters, not upstream monitoring schemas.

### Auth/Host/Origin

**restricted_fixture_source_only**. Optional key, hashed constant-time checks, exact listener Host, same-origin-only, loopback-only. Not upstream configurable CORS, Host, TLS or telemetry-key parity.

### Request validation

**partial_source_only**. Bounded body, explicit supported fields and types, bounded pending inference, context slack. Config and error schemas differ from upstream; duplicate JSON keys use Go standard last-key semantics.

### FIFO/cancellation/keepalive

**source_only**. Single-sequence FIFO, bounded queue, cancellation, 10s SSE keepalive, bounded pipe writes. No batching/replicas/split/admission-priority parity.

### Lifecycle

**partial_source_only**. Signals and direct child QUIT/wait/kill/reap. No owner FD, parent-loss guarantees, process-group/tree cleanup, launch attestation, owned readiness file or Windows jobs.

### Run config and settings

**missing**. Standalone config is deliberately incompatible. No original precedence, revisions, edits, rollback, profiles or tuning.

### Launch/setup/desktop/packaging

**missing**. Only standalone exec wrapper; no audited upstream callers or shipped binary.

### Vision/MCP/images

**missing**. Not implemented; no remote or local image reads.

### Sessions/cache/VRAM/load controls

**missing**. Named controls return 501; no operational parity.

### Backends/families/platforms

**unverified**. No real model/backend tested. No CUDA/HIP/SYCL/Metal or Windows/macOS validation.

### Browser UI

**excluded**. Explicit compatibility difference.

### 20 MiB idle RSS

**unmeasured**. No Go PID exists. RSS/PSS/high-water RSS and target status remain null.

## Memory and performance

| Measurement | Actual result |
|---|---|
| Go startup RSS / PSS / peak RSS | Not measured |
| After real engine/model load | Not measured; production model path missing |
| After representative HTTP | Not measured |
| After long-context/concurrent HTTP | Not measured |
| Steady-state idle RSS | Not measured |
| Approximately 20 MiB idle target | Unverified, not met by evidence |
| Throughput / latency / Python comparison | Not measured |

No Go runtime or GC tuning was applied or measured. The exercise runner records GOGC, GOMEMLIMIT and GOMAXPROCS environment values, runtime version from capabilities, OS, workload, PID and phase-specific measurements if a real executable becomes available. It reads only that PID's `/proc/PID/status` and `smaps_rollup`; KiB values are divided by 1024 to interpret MiB. VmHWM is a lifetime high-water value, not a sampled phase-local peak. It excludes the measurement process and child engines by PID.

The supplied workload uses an isolated mock, 12 requests with 4 concurrent clients, a 50,000-byte fixture prompt and a configurable idle interval. Even a future successful fixture memory result would not establish memory after real tokenizer/template load. No constant 20 MiB ceiling is claimed. There is no real-model load phase in the current runner.

## Important implementation limits

- Fixture config is a new, strict schema. It must not be substituted for existing run configs.
- Production mode is unavailable. Sending byte IDs to a real model would be wrong; no supported flag advertises that as working.
- No native binary or model was downloaded, started or tested.
- Tool parsing is independent source only; HTTP tools are rejected. Quoted/fenced markers, declared schema string coercion, aliases, recovery, DSML and incomplete-call parity are not implemented.
- BPE merge code is not a tokenizer. It lacks vocabulary loading and family pre-tokenization. It is unused by the HTTP byte fixture.
- Truncated UTF-8 currently fails rather than reproducing upstream truncation behavior. Fixture token counts are UTF-8 byte counts, not model tokens.
- Queue order is FIFO after request decoding, not a claim about upstream arrival/admission semantics. Inference bodies are bounded after handler admission; HTTP connection count itself is not globally capped.
- Child cleanup covers only the directly spawned process. No process-tree or owner-loss guarantee is made. Engine crashes fail requests; automatic restart is absent.
- The health endpoint describes HTTP process liveness, not native-engine readiness.
- Streaming errors are terminal error frames without a successful completion marker. Exact upstream error envelopes and usage-stream semantics are not preserved.
- There is no reviewed upstream integration patch. Existing setup, CLI, desktop, Intel path and packaging remain unmodified and unverified.

## Acceptance verdict

**Incomplete.** The source and tested support fixtures are delivered; full serving parity, a built executable, Go test results, real HTTP execution and the memory target are not delivered. No missing feature is marked complete. No additional user upload is required to inspect this package, but this sandbox cannot execute Go without an available compiler.

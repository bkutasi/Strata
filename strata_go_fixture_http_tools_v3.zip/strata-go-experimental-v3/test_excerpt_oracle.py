"""Reference/corpus checks only; these never execute the Go parser."""
import json
from pathlib import Path
import unittest
from excerpt_oracle import cases, json_tool_call, param_end, parse_tool_call


class ExcerptOracleTests(unittest.TestCase):
    def test_committed_corpus_matches_reference(self):
        self.assertEqual(json.loads((Path(__file__).resolve().parent / 'tool_oracle_cases.json').read_text()), cases())

    def test_declared_string_preserves_json_looking_values(self):
        schema = {'parameters': {'properties': {'x': {'type': 'string'}}}}
        for value in ['123', 'null', 'true', '"x"', '{"a":1}']:
            with self.subTest(value=value):
                self.assertEqual(parse_tool_call('<function=f><parameter=x>' + value + '</parameter></function>', schema)['arguments']['x'], value)

    def test_json_declared_only_and_string_arguments(self):
        self.assertIsNone(json_tool_call('{"name":"unknown"}', {'read': {}}))
        self.assertEqual(json_tool_call('{"name":"read","arguments":"{\\"x\\":1}"}', {'read': {}})['arguments'], {'x': 1})

    def test_boundary_and_wait_cases(self):
        self.assertEqual(param_end('x</parameter>'), -2)
        self.assertEqual(param_end('x</parameter>', True), 1)
        self.assertEqual(param_end('x</parameter></fun'), -2)
        text = 'x</parameter>literal</parameter></function>'
        self.assertEqual(param_end(text), text.rindex('</parameter>'))

    def test_embedded_closers_are_values(self):
        value = 'text </function></tool_call> text'
        body = '<function=read><parameter=x>' + value + '</parameter></function>'
        self.assertEqual(parse_tool_call(body)['arguments']['x'], value)

    def test_confirmed_final_partial_followers(self):
        for follower in ('', ' ', '</fun', '<para', '<parameter=', '</function>', '<parameter=x>'):
            text = 'x</parameter>' + follower
            with self.subTest(follower=follower):
                self.assertEqual(param_end(text, True), 1)
                complete = follower.strip().startswith(('<parameter=', '</function>'))
                self.assertEqual(param_end(text, False), 1 if complete else -2)
        for follower in ('</fun', '<para'):
            self.assertEqual(parse_tool_call('<function=read><parameter=x>x</parameter>' + follower)['arguments']['x'], 'x')


if __name__ == '__main__':
    unittest.main(verbosity=2)

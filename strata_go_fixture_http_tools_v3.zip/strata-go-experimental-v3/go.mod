module strata-go-experimental

go 1.22

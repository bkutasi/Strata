package main
import("strings";"testing";"net/http/httptest")
// Historical negative shapes remain rejected: missing schema and required choice without tools.
func TestHTTPToolsRemainUnavailable(t *testing.T){_,ts:=testService(t,"")
 for _,field:=range []string{`"tools":[{"type":"function","function":{"name":"read"}}]`,`"tool_choice":"required"`}{body:=strings.TrimSuffix(basic,"}")+","+field+"}";status,b:=call(t,ts,"/v1/chat/completions",body,"",nil);if status!=400{t.Fatal(status,b)}}
}
func TestHTTPToolOutputNeverClaimsSuccess(t *testing.T){
 cfg:=defaultConfig();cfg.Engine="mock";s:=newService(cfg,&ByteEngine{Script:"<tool_call><function=read></function></tool_call>"})
 // Existing helper uses a real loopback listener; construct it with the desired script before serving.
 ts:=fixtureHTTPServer(t,s)
 for _,stream:=range []bool{false,true}{body:=basic;if stream{body=strings.TrimSuffix(basic,"}")+`,"stream":true}`};status,b:=call(t,ts,"/v1/chat/completions",body,"",nil)
  if !stream&&status!=502{t.Fatal(status,b)};if stream&&(strings.Contains(b,"[DONE]")||!strings.Contains(b,`"error"`)){t.Fatal(b)}
 }
}

func fixtureHTTPServer(t *testing.T,s *service)*httptest.Server{t.Helper();ts:=httptest.NewUnstartedServer(s);s.authority=ts.Listener.Addr().String();ts.Start();t.Cleanup(ts.Close);return ts}

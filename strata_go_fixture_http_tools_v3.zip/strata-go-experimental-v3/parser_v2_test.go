package main

import("encoding/json";"os";"reflect";"strings";"testing")
func toolSchemas()map[string]map[string]any{return map[string]map[string]any{"read":{"parameters":map[string]any{"properties":map[string]any{"path":map[string]any{"type":"string"}}}}}}
func TestDeclaredStringArguments(t *testing.T){
 for _,value:=range []string{"123","true","null",`"quoted"`,`{"x":1}`,"\n\nline\n\n","","  padded  "}{
  body:="<function=read><parameter=path>"+value+"</parameter></function>"
  call,err:=parseToolCall(body,toolSchemas()["read"]);if err!=nil{t.Fatal(err)}
  want:=strings.TrimSuffix(strings.TrimPrefix(value,"\n"),"\n");if call.Arguments["path"]!=want{t.Fatalf("%q: %#v",value,call.Arguments)}
 }
 for _,c:=range []struct{value string;want any}{{"123",json.Number("123")},{"true",true},{"null",nil},{`"quoted"`,"quoted"},{"plain","plain"}}{
  call,err:=parseCall("<function=read><parameter=x>"+c.value+"</parameter></function>");if err!=nil||!reflect.DeepEqual(call.Arguments["x"],c.want){t.Fatal(call,err)}
 }
}
func TestParameterBoundaryCases(t *testing.T){
 for _,c:=range []struct{text string;final bool;want int}{
  {"abc",false,-1},{"x</parameter>",false,-2},{"x</parameter>",true,1},
  {"x</parameter>  </fun",false,-2},{"x</parameter>  </fun",true,1},
  {"x</parameter>\n<parameter=y>",false,1},{"x</parameter> </function>",false,1},
  {"x</parameter>literal",true,-1},{"x</parameter>literal</parameter></function>",false,20},
 }{if got:=parameterEnd(c.text,c.final);got!=c.want{t.Fatalf("%q final=%v got=%d want=%d",c.text,c.final,got,c.want)}}
}
func TestJSONToolCallCases(t *testing.T){
 for _,c:=range []struct{body string;valid bool;args map[string]any}{
  {`{"name":"read","arguments":{"path":"x"}}`,true,map[string]any{"path":"x"}},
  {`{"name":"read","parameters":{"n":1}}`,true,map[string]any{"n":json.Number("1")}},
  {`{"name":"read","arguments":"{\"path\":\"x\"}"}`,true,map[string]any{"path":"x"}},
  {`{"name":"read","arguments":null}`,true,map[string]any{}},
  {`{"name":"read"}`,true,map[string]any{}},
  {"```JSON\r\n{\"name\":\"read\",\"arguments\":{}}\r\n```",true,map[string]any{}},
  {`{"name":"read","arguments":{},"parameters":[]}`,true,map[string]any{}},
  {`{"name":"read","arguments":[]}`,false,nil},{`{"name":"read","arguments":"broken"}`,false,nil},
  {`{"name":"unknown","arguments":{}}`,false,nil},{`{"name":null}`,false,nil},{`[]`,false,nil},
  {`{"name":"read","arguments":false}`,false,nil},{`{"name":"read"} trailing`,false,nil},
 }{call:=jsonToolCall(c.body,toolSchemas());if (call!=nil)!=c.valid{t.Fatalf("%s: %#v",c.body,call)};if call!=nil&&!reflect.DeepEqual(call.Arguments,c.args){t.Fatalf("%s: %#v",c.body,call)}}
}
func TestToolStreamsAllSplitPoints(t *testing.T){
 xml:="<function=read><parameter=path>123 </function> </tool_call> </parameter> literal</parameter></function>"
 jsonBody:=`{"name":"read","arguments":{"path":"</tool_call> </function> { [ \\\"","nested":{"x":[1,2]}}}`
 for _,body:=range []string{xml,jsonBody,"```json\n"+jsonBody+"\n```"}{
  script:="why</think>before<tool_call> \n"+body+" \n</tool_call>after"
  for split:=0;split<=len(script);split++{
   p:=NewParser(true,ParserOptions{Schemas:toolSchemas(),DeclaredOnly:true});events:=[]Event{}
   for _,part:=range []string{script[:split],script[split:]}{got,err:=p.Feed(part,false);if err!=nil{t.Fatalf("split %d body %s: %v",split,body,err)};events=append(events,got...)}
   got,err:=p.Feed("",true);if err!=nil{t.Fatal(err)};events=append(events,got...)
   reasoning,content:="","";calls:=0
   for _,ev:=range events{switch ev.Kind{case "reasoning":reasoning+=ev.Text;case "content":content+=ev.Text;case "tool_call":calls++;if ev.Call.Name!="read"{t.Fatal(ev.Call)}}}
   if reasoning!="why"||content!="beforeafter"||calls!=1{t.Fatalf("split=%d events=%#v",split,events)}
  }
  p:=NewParser(true,ParserOptions{Schemas:toolSchemas()});calls:=0
  for i:=0;i<len(script);i++{events,err:=p.Feed(script[i:i+1],false);if err!=nil{t.Fatal(i,err)};for _,ev:=range events{if ev.Call!=nil{calls++}}};if _,err:=p.Feed("",true);err!=nil||calls!=1{t.Fatal(calls,err)}
 }
}
func TestIncompleteCallsEveryPrefix(t *testing.T){
 for _,body:=range []string{"<function=read><parameter=path>x</parameter></function>",`{"name":"read","arguments":{"path":"x"}}`,"```json\n{\"name\":\"read\"}\n```"}{
  full:="<tool_call>"+body+"</tool_call>"
  for end:=len("<tool_call>");end<len(full);end++{p:=NewParser(false,ParserOptions{Schemas:toolSchemas()});events,err:=p.Feed(full[:end],true);if err==nil{t.Fatalf("accepted prefix %q",full[:end])};for _,ev:=range events{if ev.Call!=nil{t.Fatalf("premature call: %#v",ev)}}}
 }
}
func TestPartialMarkersAndFinalization(t *testing.T){
 for _,text:=range []string{"<","<tool_","</thi","plain {\"name\":\"read\"}"}{p:=NewParser(false);events,err:=p.Feed(text,true);if err!=nil{t.Fatal(err)};got:="";for _,ev:=range events{got+=ev.Text};if got!=text{t.Fatal(got)};if _,err=p.Feed("",true);err==nil{t.Fatal("accepted feed after finalization")}}
 p:=NewParser(false,ParserOptions{MaxBufferedBytes:16});if _,err:=p.Feed("<tool_call>"+strings.Repeat("x",20),false);err==nil{t.Fatal("limit not enforced")};if _,err:=p.Feed("",false);err==nil{t.Fatal("error was not sticky")}
}
func TestDeclaredOnlyAndConsecutiveCalls(t *testing.T){
 for _,options:=range []ParserOptions{{DeclaredOnly:true},{Schemas:toolSchemas()}}{p:=NewParser(false,options);if _,err:=p.Feed("<tool_call><function=unknown></function></tool_call>",true);err==nil{t.Fatal("undeclared call accepted")}}
 p:=NewParser(false,ParserOptions{Schemas:toolSchemas()});script:=strings.Repeat("<tool_call><function=read></function></tool_call>",2);events,err:=p.Feed(script,true);if err!=nil||len(events)!=2{t.Fatal(events,err)}
}
func TestCallEndNestedLookingText(t *testing.T){body:="<function=read><parameter=path>a </function></tool_call> b</parameter></function>\n</tool_call>tail";want:=strings.LastIndex(body,"</tool_call>");if got:=callEnd(body);got!=want{t.Fatal(got,want)};if callEnd("<function=read>")!=-1{t.Fatal("incomplete")};if callEnd("other</tool_call>")!=5{t.Fatal("fallback")}}
func TestToolChoiceForms(t *testing.T){
 for _,c:=range []struct{input any;kind,name string}{
  {"auto","auto",""},{"none","none",""},{"required","required",""},{nil,"unknown",""},{"any","unknown",""},
  {map[string]any{"type":"any"},"required",""},{map[string]any{"type":"none"},"none",""},
  {map[string]any{"type":"tool","name":"read"},"named","read"},
  {map[string]any{"type":"function","name":"read"},"named","read"},
  {map[string]any{"type":"function","function":map[string]any{"name":"read"}},"named","read"},
  {map[string]any{"type":"function","function":false,"name":"read"},"named","read"},
  {map[string]any{"type":"tool","name":7},"unknown",""},
 }{kind,name:=toolChoiceOf(c.input);if kind!=c.kind||name!=c.name{t.Fatal(c,kind,name)}}
 one:=[]map[string]any{{"name":"read"}};two:=append(append([]map[string]any{},one...),map[string]any{"name":"write"})
 if forcedCall("required",one)!="<tool_call>\n<function=read>"{t.Fatal("single required")}
 if forcedCall(map[string]any{"type":"any"},two)!="<tool_call>\n<function="{t.Fatal("multiple required")}
 for _,choice:=range []any{"none","auto","bad",map[string]any{"type":"tool","name":"unknown"}}{if forcedCall(choice,one)!=""{t.Fatal(choice)}}
 if forcedCall("required",nil)!=""{t.Fatal("no tools")}
 if forcedCall(map[string]any{"type":"tool","name":"bad>"},[]map[string]any{{"name":"bad>"}})!=""{t.Fatal("markup injection")}
}
func TestExcerptOracleCorpus(t *testing.T){
 data,err:=os.ReadFile("tool_oracle_cases.json");if err!=nil{t.Fatal(err)}
 var cases []struct{Name string `json:"case"`;Mode string `json:"mode"`;Body string `json:"body"`;Schema map[string]any `json:"schema"`;Schemas map[string]map[string]any `json:"schemas"`;Expected *Call `json:"expected"`}
 dec:=json.NewDecoder(strings.NewReader(string(data)));dec.UseNumber();if err=dec.Decode(&cases);err!=nil{t.Fatal(err)}
 for _,c:=range cases{t.Run(c.Name,func(t *testing.T){var got *Call;var err error;if c.Mode=="xml"{got,err=parseToolCall(c.Body,c.Schema)}else{got=jsonToolCall(c.Body,c.Schemas)};if err!=nil{t.Fatal(err)};if !reflect.DeepEqual(got,c.Expected){t.Fatalf("got=%#v want=%#v",got,c.Expected)}})}
}

func TestToolNumbersKeepPrecision(t *testing.T){
 for _,number:=range []string{"9007199254740993","123456789012345678901234567890","-0","1.25e100"}{
  call,err:=parseToolCall("<function=read><parameter=n>"+number+"</parameter></function>",nil);if err!=nil{t.Fatal(err)}
  if got,ok:=call.Arguments["n"].(json.Number);!ok||string(got)!=number{t.Fatalf("rounded number: %#v",call)}
  call=jsonToolCall(`{"name":"read","arguments":{"n":`+number+`}}`,toolSchemas());if call==nil||call.Arguments["n"]!=json.Number(number){t.Fatal(call)}
 }
 for _,text:=range []string{"NaN","Infinity","1 2"}{if _,err:=decodeToolJSON(text);err==nil{t.Fatal("invalid JSON accepted",text)}}
}

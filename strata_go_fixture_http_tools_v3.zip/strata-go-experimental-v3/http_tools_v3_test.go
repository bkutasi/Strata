package main

import (
 "bufio"
 "context"
 "encoding/json"
 "errors"
 "fmt"
 "net/http/httptest"
 "os"
 "reflect"
 "strconv"
 "strings"
 "sync"
 "testing"
 "time"
)
const xmlFixtureCall="<tool_call><function=read><parameter=path>123</parameter><parameter=n>9007199254740993</parameter><parameter=flag>true</parameter><parameter=obj>{\"x\":1}</parameter><parameter=arr>[1,\"東京\"]</parameter><parameter=nil>null</parameter></function></tool_call>"
func fixtureToolDefinition(anthropic bool,name string)map[string]any{
 schema:=map[string]any{"type":"object","properties":map[string]any{"path":map[string]any{"type":"string"},"n":map[string]any{"type":"integer"},"flag":map[string]any{"type":"boolean"},"obj":map[string]any{"type":"object"},"arr":map[string]any{"type":"array"},"nil":map[string]any{"type":"null"}},"required":[]any{"path"},"additionalProperties":false}
 if anthropic{return map[string]any{"name":name,"input_schema":schema}}
 return map[string]any{"type":"function","function":map[string]any{"name":name,"parameters":schema}}
}
func fixtureRequest(anthropic,stream bool)map[string]any{return map[string]any{"model":"strata-byte-fixture","messages":[]any{map[string]any{"role":"user","content":"Grüße 東京"}},"tools":[]any{fixtureToolDefinition(anthropic,"read")},"stream":stream}}
func encodeRequest(t *testing.T,v any)string{t.Helper();b,err:=json.Marshal(v);if err!=nil{t.Fatal(err)};return string(b)}
func jsonObject(t *testing.T,body string)map[string]any{t.Helper();v,err:=decodeToolJSON(body);if err!=nil{t.Fatal(body,err)};m,err:=object(v,"response");if err!=nil{t.Fatal(err)};return m}
func pathFor(anthropic bool)string{if anthropic{return "/v1/messages"};return "/v1/chat/completions"}
func outputCalls(t *testing.T,body string,anthropic bool)[]map[string]any{
 t.Helper();m:=jsonObject(t,body);calls:=[]map[string]any{}
 if anthropic{if m["stop_reason"]!="tool_use"{t.Fatal(m)};for _,block:=range m["content"].([]any){b:=block.(map[string]any);if b["type"]=="tool_use"{calls=append(calls,map[string]any{"id":b["id"],"name":b["name"],"args":b["input"]})}}
 }else{choice:=m["choices"].([]any)[0].(map[string]any);if choice["finish_reason"]!="tool_calls"{t.Fatal(choice)};msg:=choice["message"].(map[string]any);for _,value:=range msg["tool_calls"].([]any){call:=value.(map[string]any);fn:=call["function"].(map[string]any);args,err:=decodeToolJSON(fn["arguments"].(string));if err!=nil{t.Fatal(err)};calls=append(calls,map[string]any{"id":call["id"],"name":fn["name"],"args":args})}}
 return calls
}
func checkFixtureArguments(t *testing.T,args map[string]any){t.Helper();want:=map[string]any{"path":"123","n":json.Number("9007199254740993"),"flag":true,"obj":map[string]any{"x":json.Number("1")},"arr":[]any{json.Number("1"),"東京"},"nil":nil};if !reflect.DeepEqual(args,want){t.Fatalf("args=%#v",args)}}
func TestHTTPFixtureToolsNonStreaming(t *testing.T){
 for _,anthropic:=range []bool{false,true}{cfg:=defaultConfig();cfg.Engine="mock";s:=newService(cfg,&ByteEngine{Script:"before"+xmlFixtureCall+xmlFixtureCall+"after"});ts:=fixtureHTTPServer(t,s)
  status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,fixtureRequest(anthropic,false)),"",nil);if status!=200{t.Fatal(status,body)};calls:=outputCalls(t,body,anthropic);if len(calls)!=2{t.Fatal(calls)}
  for _,call:=range calls{if call["name"]!="read"||!validID(call["id"].(string)){t.Fatal(call)};checkFixtureArguments(t,call["args"].(map[string]any))};if calls[0]["id"]==calls[1]["id"]{t.Fatal("duplicate generated ID")}
 }
}
type fixtureFrame struct{event string;data map[string]any;done bool}
func frames(t *testing.T,body string)[]fixtureFrame{
 t.Helper();out:=[]fixtureFrame{};event:=""
 for _,line:=range strings.Split(body,"\n"){if strings.HasPrefix(line,"event: "){event=strings.TrimPrefix(line,"event: ")};if strings.HasPrefix(line,"data: "){text:=strings.TrimPrefix(line,"data: ");if text=="[DONE]"{out=append(out,fixtureFrame{done:true})}else{out=append(out,fixtureFrame{event:event,data:jsonObject(t,text)})};event=""}}
 return out
}
func TestHTTPFixtureToolStreamEventOrder(t *testing.T){
 for _,anthropic:=range []bool{false,true}{cfg:=defaultConfig();cfg.Engine="mock";s:=newService(cfg,&ByteEngine{Script:"before"+xmlFixtureCall+xmlFixtureCall+"after"});ts:=fixtureHTTPServer(t,s)
  status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,fixtureRequest(anthropic,true)),"",nil);if status!=200{t.Fatal(status,body)};list:=frames(t,body)
  if anthropic{
   want:=[]string{"message_start","content_block_start","content_block_delta","content_block_stop","content_block_start","content_block_delta","content_block_stop","content_block_start","content_block_delta","content_block_stop","content_block_start","content_block_delta","content_block_stop","message_delta","message_stop"}
   got:=[]string{};ids:=map[string]bool{};toolCount:=0;open:=-1
   for _,f:=range list{got=append(got,f.event);if f.event=="content_block_start"{if open!=-1{t.Fatal("overlapping blocks")};open=numberIndex(t,f.data["index"])}
    if f.event=="content_block_start"{block:=f.data["content_block"].(map[string]any);if block["type"]=="tool_use"{id:=block["id"].(string);if ids[id]{t.Fatal("duplicate ID")};ids[id]=true;toolCount++}}
    if f.event=="content_block_delta"{delta:=f.data["delta"].(map[string]any);if delta["type"]=="input_json_delta"{args:=jsonObject(t,delta["partial_json"].(string));checkFixtureArguments(t,args)}}
    if f.event=="content_block_stop"{open=-1}
   };if !reflect.DeepEqual(got,want)||toolCount!=2{t.Fatal(got,toolCount,body)};if list[len(list)-2].data["delta"].(map[string]any)["stop_reason"]!="tool_use"{t.Fatal(body)}
  }else{
   if !list[len(list)-1].done{t.Fatal("missing DONE")};first:=list[0].data["choices"].([]any)[0].(map[string]any);if first["delta"].(map[string]any)["role"]!="assistant"{t.Fatal(body)}
   count:=0;ids:=map[string]bool{};for _,f:=range list{if f.done{continue};choice:=f.data["choices"].([]any)[0].(map[string]any);delta:=choice["delta"].(map[string]any);if value,ok:=delta["tool_calls"];ok{c:=value.([]any)[0].(map[string]any);if c["index"]!=json.Number(strconv.Itoa(count)){t.Fatal(c)};id:=c["id"].(string);if ids[id]{t.Fatal("duplicate ID")};ids[id]=true;fn:=c["function"].(map[string]any);checkFixtureArguments(t,jsonObject(t,fn["arguments"].(string)));count++}}
   if count!=2||list[len(list)-2].data["choices"].([]any)[0].(map[string]any)["finish_reason"]!="tool_calls"{t.Fatal(body)}
  }
 }
}
// captureFixture is a mock engine with a real prompt observation channel, not polling.
type captureFixture struct{base Engine;prompts chan []int}
func(e *captureFixture) Generate(ctx context.Context,ids []int,cap int,emit func(int)error)(string,error){e.prompts<-append([]int(nil),ids...);return e.base.Generate(ctx,ids,cap,emit)}
func(e *captureFixture) Close()error{return e.base.Close()}
func TestHTTPToolResultReplayAndSyntheticPrompt(t *testing.T){
 for _,anthropic:=range []bool{false,true}{cfg:=defaultConfig();cfg.Engine="mock";e:=&captureFixture{base:&ByteEngine{Script:xmlFixtureCall},prompts:make(chan []int,2)};s:=newService(cfg,e);ts:=fixtureHTTPServer(t,s)
  req:=fixtureRequest(anthropic,false);status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=200{t.Fatal(status,body)};generated:=outputCalls(t,body,anthropic)[0];<-e.prompts
  if anthropic{req["messages"]=[]any{map[string]any{"role":"assistant","content":[]any{map[string]any{"type":"tool_use","id":generated["id"],"name":"read","input":generated["args"]}}},map[string]any{"role":"user","content":[]any{map[string]any{"type":"tool_result","tool_use_id":generated["id"],"content":"résultat 東京","is_error":false}}}}
  }else{args,_:=json.Marshal(generated["args"]);req["messages"]=[]any{map[string]any{"role":"assistant","content":nil,"tool_calls":[]any{map[string]any{"id":generated["id"],"type":"function","function":map[string]any{"name":"read","arguments":string(args)}}}},map[string]any{"role":"tool","tool_call_id":generated["id"],"content":"résultat 東京"}}}
  status,body=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=200{t.Fatal(status,body)};ids:=<-e.prompts;bytes:=make([]byte,len(ids));for i,id:=range ids{bytes[i]=byte(id)};prompt:=jsonObject(t,string(bytes));if prompt["fixture_format"]!="strata-byte-tools-v1"||prompt["not_a_model_template"]!=true{t.Fatal(prompt)}
  turns:=prompt["messages"].([]any);first:=turns[0].(map[string]any);replay:=first["tool_calls"].([]any)[0].(map[string]any);if replay["id"]!=generated["id"]||replay["name"]!="read"{t.Fatal(prompt)};if turns[1].(map[string]any)["tool_call_id"]!=generated["id"]||turns[1].(map[string]any)["content"]!="résultat 東京"{t.Fatal(prompt)}
 }
}
func TestHTTPToolChoices(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,kind:=range []string{"auto","none","required","named","required-multiple"}{
  t.Run(fmt.Sprintf("anthropic=%v/%s",anthropic,kind),func(t *testing.T){req:=fixtureRequest(anthropic,false);script:=xmlFixtureCall;choice:=kind
   if kind=="required-multiple"{choice="required";req["tools"]=[]any{fixtureToolDefinition(anthropic,"read"),fixtureToolDefinition(anthropic,"other")};script=strings.TrimPrefix(xmlFixtureCall,"<tool_call><function=")
   }else if kind=="required"||kind=="named"{script=strings.TrimPrefix(xmlFixtureCall,"<tool_call><function=read>")}
   if kind=="none"{script="no call"}
   if anthropic{typ:=choice;if choice=="required"{typ="any"};if choice=="named"{typ="tool"};m:=map[string]any{"type":typ};if kind=="named"{m["name"]="read"};req["tool_choice"]=m
   }else if kind=="named"{req["tool_choice"]=map[string]any{"type":"function","function":map[string]any{"name":"read"}}}else{req["tool_choice"]=choice}
   cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:script}));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=200{t.Fatal(status,body)};if kind!="none"{if len(outputCalls(t,body,anthropic))!=1{t.Fatal(body)}}else if strings.Contains(body,`"tool_calls"`)||strings.Contains(body,`"tool_use"`){t.Fatal(body)}
  })
 }}
}
func TestHTTPToolValidationRejectsUnsupported(t *testing.T){
 cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:"ok"}))
 for _,anthropic:=range []bool{false,true}{for _,mutate:=range []func(map[string]any){
  func(r map[string]any){r["tools"]=[]any{}},func(r map[string]any){r["tools"]=nil},
  func(r map[string]any){r["tools"]=[]any{fixtureToolDefinition(anthropic,"read"),fixtureToolDefinition(anthropic,"read")}},
  func(r map[string]any){r["tools"]=[]any{fixtureToolDefinition(anthropic,"bad>")}},
  func(r map[string]any){r["tool_choice"]=nil},func(r map[string]any){r["tool_choice"]=map[string]any{"type":"unsupported"}},
  func(r map[string]any){if anthropic{r["tool_choice"]=map[string]any{"type":"tool","name":"unknown"}}else{r["tool_choice"]=map[string]any{"type":"function","name":"unknown"}}},
  func(r map[string]any){tool:=fixtureToolDefinition(anthropic,"read");if anthropic{tool["input_schema"]=map[string]any{"type":"object","$ref":"x"}}else{tool["function"].(map[string]any)["parameters"]=map[string]any{"type":"object","$ref":"x"}};r["tools"]=[]any{tool}},
  func(r map[string]any){r["messages"]=[]any{map[string]any{"role":"tool","tool_call_id":"orphan","content":"x"}}},
 }{req:=fixtureRequest(anthropic,false);mutate(req);status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=400{t.Fatal(anthropic,status,body)}}}
}
func TestHTTPToolOutputFailuresAreAtomic(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{for _,bad:=range []string{
  "<tool_call><function=read><parameter=path>x</parameter></fun",
  xmlFixtureCall+"<tool_call>",
  strings.Replace(xmlFixtureCall,"function=read","function=unknown",1),
  strings.Replace(xmlFixtureCall,"<parameter=n>9007199254740993","<parameter=n>not integer",1),
  strings.Replace(xmlFixtureCall,"<parameter=path>123</parameter>","",1),
 }{cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:bad}));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,fixtureRequest(anthropic,stream)),"",nil)
  if !stream&&status!=502{t.Fatal(status,body)};if stream{if !strings.Contains(body,`"error"`)||strings.Contains(body,"[DONE]")||strings.Contains(body,"event: message_stop")||strings.Contains(body,`"type":"tool_use"`)||strings.Contains(body,`"tool_calls":[`){t.Fatal(body)}}
 }}}
}
// The helper emits one byte per record. Hold mode waits for STOP after complete output,
// allowing cancellation after a syntactically complete call but before engine DONE.
func TestHTTPToolProtocolHelper(t *testing.T){
 if os.Getenv("STRATA_HTTP_TOOL_HELPER")!="1"{return}
 script:=os.Getenv("STRATA_HTTP_TOOL_SCRIPT");mode:=os.Getenv("STRATA_HTTP_TOOL_MODE");fmt.Println("READY 65536 stop fixture-byte-v1")
 scan:=bufio.NewScanner(os.Stdin);for scan.Scan(){line:=scan.Text();if line=="QUIT"{os.Exit(0)};if line=="STOP"{fmt.Println("DONE finish=stop");continue};if !strings.HasPrefix(line,"GEN "){fmt.Println("ERR bad fixture command");continue}
  parts:=strings.SplitN(line," ",3);if len(parts)!=3{fmt.Println("ERR missing prompt");continue};ids:=strings.Split(parts[2],",");prompt:=make([]byte,len(ids));valid:=true;for i,id:=range ids{n,err:=strconv.Atoi(id);if err!=nil||n<0||n>255{valid=false;break};prompt[i]=byte(n)}
  if !valid||!strings.Contains(string(prompt),`"fixture_format":"strata-byte-tools-v1"`){fmt.Println("ERR expected synthetic tool prompt");continue}
  cap,err:=strconv.Atoi(parts[1]);if err!=nil{fmt.Println("ERR bad limit");continue};data:=[]byte(script);finish:="stop";if len(data)>cap{data=data[:cap];finish="length"};for _,b:=range data{fmt.Printf("T %d\n",b)}
  switch mode{case "error":fmt.Println("ERR after complete call");case "eof":os.Exit(7);case "hold":fmt.Println("INFO fixture-output-complete");default:fmt.Println("DONE finish="+finish)}
 };os.Exit(0)
}
func httpToolWire(t *testing.T,script,mode string)*WireEngine{t.Helper();t.Setenv("STRATA_HTTP_TOOL_HELPER","1");t.Setenv("STRATA_HTTP_TOOL_SCRIPT",script);t.Setenv("STRATA_HTTP_TOOL_MODE",mode);e,err:=startWire(context.Background(),[]string{os.Args[0],"-test.run=^TestHTTPToolProtocolHelper$"},5*time.Second);if err!=nil{t.Fatal(err)};t.Cleanup(func(){_ = e.Close()});return e}
func TestHTTPToolsThroughProtocolFixture(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{for _,mode:=range []string{"ok","error","eof"}{t.Run(fmt.Sprintf("%v/%v/%s",anthropic,stream,mode),func(t *testing.T){e:=httpToolWire(t,xmlFixtureCall,mode);cfg:=defaultConfig();cfg.Engine="protocol-fixture";ts:=fixtureHTTPServer(t,newService(cfg,e));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,fixtureRequest(anthropic,stream)),"",nil)
  if mode=="ok"{if status!=200{t.Fatal(status,body)};if !stream{checkFixtureArguments(t,outputCalls(t,body,anthropic)[0]["args"].(map[string]any))}else if !strings.Contains(body,`"name":"read"`){t.Fatal(body)}
  }else{if !stream&&status!=502{t.Fatal(status,body)};if stream&&(strings.Contains(body,"[DONE]")||strings.Contains(body,"event: message_stop")||strings.Contains(body,`"name":"read"`)){t.Fatal(body)}}
 })}}}
}
// Signal after the last emitted byte, not after a sleep. Used to cancel before DONE.
type heldFixture struct{script string;emitted chan struct{};released chan struct{};once sync.Once;err error}
func(e *heldFixture) Generate(ctx context.Context,ids []int,cap int,emit func(int)error)(string,error){for _,b:=range []byte(e.script){if err:=emit(int(b));err!=nil{return "",err}};e.once.Do(func(){close(e.emitted)});select{case <-ctx.Done():return "",ctx.Err();case <-e.released:return "stop",e.err}}
func(e *heldFixture) Close()error{return nil}
func TestHTTPToolCancellationBeforeCommit(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{e:=&heldFixture{script:xmlFixtureCall,emitted:make(chan struct{}),released:make(chan struct{})};cfg:=defaultConfig();cfg.Engine="mock";s:=newService(cfg,e);s.authority="fixture.local"
  ctx,cancel:=context.WithCancel(context.Background());req:=httptest.NewRequest("POST","http://fixture.local"+pathFor(anthropic),strings.NewReader(encodeRequest(t,fixtureRequest(anthropic,stream)))).WithContext(ctx);req.Header.Set("Content-Type","application/json");rec:=httptest.NewRecorder();done:=make(chan struct{});go func(){defer close(done);s.ServeHTTP(rec,req)}()
  select{case <-e.emitted:case <-time.After(10*time.Second):cancel();t.Fatal("no output event")};cancel();select{case <-done:case <-time.After(10*time.Second):t.Fatal("handler failed to cancel")}
  body:=rec.Body.String();if strings.Contains(body,"[DONE]")||strings.Contains(body,"event: message_stop")||strings.Contains(body,`"name":"read"`){t.Fatal(body)};if s.completed.Load()!=0{t.Fatal("cancel counted as success")};busy,n:=s.queue.State();if busy||n!=0{t.Fatal("admission leaked")}
 }}
}
func TestHTTPCompleteCallThenEngineFailure(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{e:=&heldFixture{script:xmlFixtureCall,emitted:make(chan struct{}),released:make(chan struct{}),err:errors.New("engine failed after call")};cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,e));close(e.released);status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,fixtureRequest(anthropic,stream)),"",nil)
  if !stream&&status!=502{t.Fatal(status,body)};if strings.Contains(body,`"name":"read"`)||strings.Contains(body,"[DONE]")||strings.Contains(body,"event: message_stop"){t.Fatal(body)}
 }}
}

func numberIndex(t *testing.T,v any)int{t.Helper();n,ok:=v.(json.Number);if !ok{t.Fatal(v)};i,err:=n.Int64();if err!=nil{t.Fatal(err)};return int(i)}

func TestHTTPJSONToolsUnicodeAndMarkers(t *testing.T){
 value:="東京🙂 </tool_call> </function> <parameter=x>"
 args:=map[string]any{"path":value};encoded,_:=json.Marshal(map[string]any{"name":"read","arguments":args})
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{for _,fenced:=range []bool{false,true}{body:=strings.ReplaceAll(strings.ReplaceAll(string(encoded),`\u003c`,"<"),`\u003e`,">");if fenced{body="```json\n"+body+"\n```"};cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:"<tool_call>"+body+"</tool_call>"}))
  status,response:=call(t,ts,pathFor(anthropic),encodeRequest(t,fixtureRequest(anthropic,stream)),"",nil);if status!=200{t.Fatal(status,response)}
  if !stream{if outputCalls(t,response,anthropic)[0]["args"].(map[string]any)["path"]!=value{t.Fatal(response)}}else{
   found:=false;for _,frame:=range frames(t,response){if frame.done{continue};if anthropic{if frame.event=="content_block_delta"{delta:=frame.data["delta"].(map[string]any);if delta["type"]=="input_json_delta"{if jsonObject(t,delta["partial_json"].(string))["path"]!=value{t.Fatal(response)};found=true}}}else{delta:=frame.data["choices"].([]any)[0].(map[string]any)["delta"].(map[string]any);if list,ok:=delta["tool_calls"].([]any);ok{fn:=list[0].(map[string]any)["function"].(map[string]any);if jsonObject(t,fn["arguments"].(string))["path"]!=value{t.Fatal(response)};found=true}}};if !found{t.Fatal(response)}
  }
 }}}
}
func TestHTTPToolChoiceAndTruncationFailures(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{for _,kind:=range []string{"none-call","required-no-call","named-wrong","truncated-after-call"}{
  req:=fixtureRequest(anthropic,stream);script:=xmlFixtureCall
  switch kind{
  case "none-call":if anthropic{req["tool_choice"]=map[string]any{"type":"none"}}else{req["tool_choice"]="none"}
  case "required-no-call":script="plain";if anthropic{req["tool_choice"]=map[string]any{"type":"any"}}else{req["tool_choice"]="required"}
  case "named-wrong":req["tools"]=[]any{fixtureToolDefinition(anthropic,"read"),fixtureToolDefinition(anthropic,"other")};if anthropic{req["tool_choice"]=map[string]any{"type":"tool","name":"read"}}else{req["tool_choice"]=map[string]any{"type":"function","name":"read"}};script=strings.TrimPrefix(xmlFixtureCall,"<tool_call><function=read>")+strings.Replace(xmlFixtureCall,"function=read","function=other",1)
  case "truncated-after-call":script=xmlFixtureCall+"trailing";req["max_tokens"]=len([]byte(xmlFixtureCall))
  }
  cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:script}));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil)
  if !stream&&status!=502{t.Fatal(kind,status,body)};if stream&&(strings.Contains(body,"[DONE]")||strings.Contains(body,"event: message_stop")||strings.Contains(body,`"name":"read"`)){t.Fatal(kind,body)}
 }}}
}
type observedFixture struct{base Engine;bytes int;emitted chan struct{}}
func(e *observedFixture) Generate(ctx context.Context,ids []int,cap int,emit func(int)error)(string,error){count:=0;return e.base.Generate(ctx,ids,cap,func(id int)error{if err:=emit(id);err!=nil{return err};count++;if count==e.bytes{close(e.emitted)};return nil})}
func(e *observedFixture) Close()error{return e.base.Close()}
func TestHTTPProtocolToolCancellationBeforeDONE(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,stream:=range []bool{false,true}{t.Run(fmt.Sprintf("%v/%v",anthropic,stream),func(t *testing.T){wire:=httpToolWire(t,xmlFixtureCall,"hold");e:=&observedFixture{base:wire,bytes:len([]byte(xmlFixtureCall)),emitted:make(chan struct{})};cfg:=defaultConfig();cfg.Engine="protocol-fixture";s:=newService(cfg,e);s.authority="fixture.local"
  ctx,cancel:=context.WithCancel(context.Background());defer cancel();req:=httptest.NewRequest("POST","http://fixture.local"+pathFor(anthropic),strings.NewReader(encodeRequest(t,fixtureRequest(anthropic,stream)))).WithContext(ctx);req.Header.Set("Content-Type","application/json");rec:=httptest.NewRecorder();done:=make(chan struct{});go func(){defer close(done);s.ServeHTTP(rec,req)}()
  select{case <-e.emitted:case <-time.After(10*time.Second):t.Fatal("no protocol output event")};cancel();select{case <-done:case <-time.After(10*time.Second):t.Fatal("protocol cancellation did not drain")}
  body:=rec.Body.String();if strings.Contains(body,`"name":"read"`)||strings.Contains(body,"[DONE]")||strings.Contains(body,"event: message_stop"){t.Fatal(body)}
  select{case <-wire.done:t.Fatal("valid STOP drain should preserve fixture");default:};if len(wire.gate)!=0{t.Fatal("transaction ownership leaked")}
 })}}
}
func TestHTTPReplayRejectsMissingDuplicateAndOrphanResults(t *testing.T){
 for _,anthropic:=range []bool{false,true}{for _,bad:=range []string{"missing","duplicate","orphan","wrong-role","bad-arguments"}{
  req:=fixtureRequest(anthropic,false);id:="call_previous";args:=map[string]any{"path":"x"};if bad=="bad-arguments"{args["path"]=json.Number("1")}
  if anthropic{call:=map[string]any{"type":"tool_use","id":id,"name":"read","input":args};result:=map[string]any{"type":"tool_result","tool_use_id":id,"content":"ok"};if bad=="orphan"{result["tool_use_id"]="other"};role:="user";if bad=="wrong-role"{role="assistant"};messages:=[]any{map[string]any{"role":"assistant","content":[]any{call}}};if bad!="missing"{blocks:=[]any{result};if bad=="duplicate"{blocks=append(blocks,result)};messages=append(messages,map[string]any{"role":role,"content":blocks})};req["messages"]=messages
  }else{encoded,_:=json.Marshal(args);call:=map[string]any{"id":id,"type":"function","function":map[string]any{"name":"read","arguments":string(encoded)}};result:=map[string]any{"role":"tool","tool_call_id":id,"content":"ok"};if bad=="orphan"{result["tool_call_id"]="other"};if bad=="wrong-role"{result["role"]="user"};messages:=[]any{map[string]any{"role":"assistant","content":nil,"tool_calls":[]any{call}}};if bad!="missing"{messages=append(messages,result);if bad=="duplicate"{messages=append(messages,result)}};req["messages"]=messages}
  cfg:=defaultConfig();cfg.Engine="mock";ts:=fixtureHTTPServer(t,newService(cfg,&ByteEngine{Script:"ok"}));status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=400{t.Fatal(anthropic,bad,status,body)}
 }}
}

func TestHTTPProtocolMultipleNamesAndReplay(t *testing.T){
 for _,anthropic:=range []bool{false,true}{t.Run(fmt.Sprintf("anthropic=%v",anthropic),func(t *testing.T){script:=xmlFixtureCall+strings.Replace(xmlFixtureCall,"function=read","function=other",1);wire:=httpToolWire(t,script,"ok");e:=&captureFixture{base:wire,prompts:make(chan []int,2)};cfg:=defaultConfig();cfg.Engine="protocol-fixture";ts:=fixtureHTTPServer(t,newService(cfg,e));req:=fixtureRequest(anthropic,false);req["tools"]=[]any{fixtureToolDefinition(anthropic,"read"),fixtureToolDefinition(anthropic,"other")}
  status,body:=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=200{t.Fatal(status,body)};calls:=outputCalls(t,body,anthropic);if len(calls)!=2||calls[0]["name"]!="read"||calls[1]["name"]!="other"{t.Fatal(calls)};<-e.prompts
  if anthropic{blocks:=[]any{};results:=[]any{};for _,c:=range calls{blocks=append(blocks,map[string]any{"type":"tool_use","id":c["id"],"name":c["name"],"input":c["args"]})};for i:=len(calls)-1;i>=0;i--{results=append(results,map[string]any{"type":"tool_result","tool_use_id":calls[i]["id"],"content":"ok"})};req["messages"]=[]any{map[string]any{"role":"assistant","content":blocks},map[string]any{"role":"user","content":results}}
  }else{list:=[]any{};messages:=[]any{};for _,c:=range calls{args,_:=json.Marshal(c["args"]);list=append(list,map[string]any{"id":c["id"],"type":"function","function":map[string]any{"name":c["name"],"arguments":string(args)}})};messages=append(messages,map[string]any{"role":"assistant","content":nil,"tool_calls":list});for i:=len(calls)-1;i>=0;i--{messages=append(messages,map[string]any{"role":"tool","tool_call_id":calls[i]["id"],"content":"ok"})};req["messages"]=messages}
  req["stream"]=true;status,body=call(t,ts,pathFor(anthropic),encodeRequest(t,req),"",nil);if status!=200{t.Fatal(status,body)};names:=[]string{};for _,frame:=range frames(t,body){if frame.done{continue};if anthropic{if frame.event=="content_block_start"{b:=frame.data["content_block"].(map[string]any);if b["type"]=="tool_use"{names=append(names,b["name"].(string))}}}else{delta:=frame.data["choices"].([]any)[0].(map[string]any)["delta"].(map[string]any);if list,ok:=delta["tool_calls"].([]any);ok{names=append(names,list[0].(map[string]any)["function"].(map[string]any)["name"].(string))}}};if !reflect.DeepEqual(names,[]string{"read","other"}){t.Fatal(names,body)}
  ids:=<-e.prompts;promptBytes:=make([]byte,len(ids));for i,id:=range ids{promptBytes[i]=byte(id)};prompt:=jsonObject(t,string(promptBytes));turns:=prompt["messages"].([]any);results:=[]string{};for _,turn:=range turns{m:=turn.(map[string]any);if id,ok:=m["tool_call_id"].(string);ok{results=append(results,id)}};if !reflect.DeepEqual(results,[]string{calls[1]["id"].(string),calls[0]["id"].(string)}){t.Fatal(results)}
 })}
}

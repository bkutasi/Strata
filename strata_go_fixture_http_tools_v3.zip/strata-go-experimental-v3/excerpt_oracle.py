"""Local reference for the pasted frontend.py functions, not the upstream checkout.
parse_tool_call and json_tool_call follow the supplied bodies. param_end is
reconstructed from its description, with the final partial-follower condition
corrected from the exact source condition supplied for v3.
ToolCall IDs are intentionally excluded from the comparison corpus.
"""
import json
from pathlib import Path
import re

PARAM_END = '</parameter>'
_JSON_FENCE = re.compile(r'```[ \t]*(?:json)?[ \t]*\r?\n\s*', re.I)


def param_end(text, final=False):
    at = text.find(PARAM_END)
    while at >= 0:
        after = text[at + len(PARAM_END):].lstrip()
        if after.startswith(('<parameter=', '</function>')):
            return at
        if not after or any(marker.startswith(after) for marker in ('<parameter=', '</function>')):
            return at if final else -2
        at = text.find(PARAM_END, at + 1)
    return -1


def parse_tool_call(body, schema=None):
    body = body.strip()
    if not body.startswith('<function=') or '>' not in body:
        raise ValueError('malformed tool call: ' + body[:80])
    name = body[len('<function='):body.index('>')].strip()
    rest = body[body.index('>') + 1:]
    props = ((schema or {}).get('parameters') or {}).get('properties') or {}
    args = {}
    while '<parameter=' in rest:
        rest = rest[rest.index('<parameter=') + len('<parameter='):]
        pname = rest[:rest.index('>')]
        rest = rest[rest.index('>') + 1:]
        end = param_end(rest, final=True)
        value = rest[:end] if end >= 0 else rest
        rest = rest[end + len(PARAM_END):] if end >= 0 else ''
        if value.startswith('\n'):
            value = value[1:]
        if value.endswith('\n'):
            value = value[:-1]
        declared = (props.get(pname) or {}).get('type')
        if declared == 'string':
            args[pname] = value
        else:
            try:
                args[pname] = json.loads(value)
            except ValueError:
                args[pname] = value
    return {'name': name, 'arguments': args}


def json_tool_call(body, schemas):
    body = body.strip()
    m = _JSON_FENCE.match(body)
    if m:
        body = body[m.end():].rstrip()
        body = body[:-3] if body.endswith('```') else body
    try:
        obj = json.loads(body)
    except ValueError:
        return None
    if not isinstance(obj, dict) or not isinstance(obj.get('name'), str) or obj['name'] not in schemas:
        return None
    args = obj.get('arguments', obj.get('parameters', {}))
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except ValueError:
            return None
    if args is None:
        args = {}
    return {'name': obj['name'], 'arguments': args} if isinstance(args, dict) else None


def cases():
    schema = {'parameters': {'properties': {'path': {'type': 'string'}}}}
    out = []
    for value in ['123', 'true', 'null', '"quoted"', '{"x":1}', '', '\n\nline\n\n', ' padded ', 'a </function></tool_call> b', 'a </parameter> literal']:
        body = '<function=read><parameter=path>' + value + '</parameter></function>'
        for declared in (False, True):
            use = schema if declared else {}
            out.append({'case': f'xml-{len(out)}', 'mode': 'xml', 'body': body, 'schema': use, 'expected': parse_tool_call(body, use)})
    for body in ['<function=read><parameter=x>x</parameter></fun', '<function=read><parameter=x>x</parameter><para', '<function=read>', '<function=read><parameter=x>unterminated', '<function=read><parameter=x>1</parameter><parameter=x>2</parameter></function>']:
        out.append({'case': f'xml-{len(out)}', 'mode': 'xml', 'body': body, 'schema': {}, 'expected': parse_tool_call(body)})
    schemas = {'read': schema}
    bodies = [
        '{"name":"read","arguments":{"path":"x"}}',
        '{"name":"read","parameters":{"x":1}}',
        json.dumps({'name': 'read', 'arguments': json.dumps({'path': '</tool_call> " \\'})}),
        '{"name":"read","arguments":null}', '{"name":"read"}',
        '{"name":"read","arguments":[],"parameters":{}}',
        '{"name":"read","arguments":"null"}',
        '{"name":"read","arguments":false}', '{"name":"read","arguments":"bad"}',
        '{"name":"unknown","arguments":{}}', '{"name":null}', '[]', 'broken',
        '```JSON\r\n{"name":"read","arguments":{}}\r\n```',
    ]
    for body in bodies:
        out.append({'case': f'json-{len(out)}', 'mode': 'json', 'body': body, 'schemas': schemas, 'expected': json_tool_call(body, schemas)})
    return out


if __name__ == '__main__':
    target = Path(__file__).resolve().parent / 'tool_oracle_cases.json'
    target.write_text(json.dumps(cases(), indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(f'Generated {len(cases())} excerpt-oracle cases; not a Go test result.')

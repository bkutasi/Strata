package main

import (
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "regexp"
 "strings"
 "unicode/utf8"
)

type Call struct { ID string `json:"id,omitempty"`; Name string `json:"name"`; Arguments map[string]any `json:"arguments"` }
type Event struct { Kind string; Text string; Call *Call }
// Schemas use the template shape: name -> {parameters: {properties: ...}}.
// Schemas must remain immutable while a parser is in use. Parser instances are single-owner.
// The HTTP fixture supplies normalized schemas; production templates remain unavailable.
type ParserOptions struct { Schemas map[string]map[string]any; DeclaredOnly bool; MaxBufferedBytes int }
type Parser struct { state string; buf string; limit int; options ParserOptions; ended bool; failure error }
func NewParser(thinking bool, options ...ParserOptions) *Parser {
 state:="content"; if thinking { state="reasoning" }
 p:=&Parser{state:state,limit:1<<20}
 if len(options)>0 {p.options=options[0];if p.options.MaxBufferedBytes>0 {p.limit=p.options.MaxBufferedBytes}}
 return p
}
func suffixPrefix(s,marker string) int { for n:=min(len(s),len(marker)-1);n>0;n-- {if strings.HasSuffix(s,marker[:n]) {return n}};return 0 }

// -1: no candidate; -2: a candidate whose follower has not arrived.
// A closer followed by ordinary text is part of the value, as in the excerpt.
func parameterEnd(s string, final bool) int {
 start:=0
 for {
  rel:=strings.Index(s[start:],"</parameter>");if rel<0 {return -1};i:=start+rel
  after:=strings.TrimSpace(s[i+len("</parameter>"):])
  if strings.HasPrefix(after,"<parameter=")||strings.HasPrefix(after,"</function>") {return i}
  if after==""||strings.HasPrefix("<parameter=",after)||strings.HasPrefix("</function>",after) {if final{return i};return -2}
  start=i+1
 }
}
// ponytail: rescans a bounded withheld call, O(n^2) for tiny chunks; use a persistent cursor for large production calls.
func functionEnd(s string) int {
 if !strings.HasPrefix(s,"<function=") {return -1};gt:=strings.IndexByte(s,'>');if gt<0 {return -1};pos:=gt+1
 for {
  rest:=s[pos:];trim:=strings.TrimLeft(rest," \t\r\n");pos+=len(rest)-len(trim)
  if strings.HasPrefix(trim,"</function>") {return pos+len("</function>")}
  if !strings.HasPrefix(trim,"<parameter=") {return -1};gt=strings.IndexByte(trim,'>');if gt<0{return -1}
  valueStart:=pos+gt+1;end:=parameterEnd(s[valueStart:],false);if end<0{return -1};pos=valueStart+end+len("</parameter>")
 }
}
// Index of the outer call closer. XML parameters are walked, not searched blindly.
// Non-XML fallback matches the described call_end behavior, not JSON string handling.
func callEnd(text string) int {
 trim:=strings.TrimLeft(text," \t\r\n");offset:=len(text)-len(trim)
 if !strings.HasPrefix(trim,"<function=") {return strings.Index(text,"</tool_call>")}
 end:=functionEnd(trim);if end<0{return -1}
 tail:=text[offset+end:];after:=strings.TrimLeft(tail," \t\r\n");space:=len(tail)-len(after)
 if strings.HasPrefix(after,"</tool_call>") {return offset+end+space};return -1
}
func declaredString(schema map[string]any,name string) bool {
 params,_:=schema["parameters"].(map[string]any);props,_:=params["properties"].(map[string]any);prop,_:=props[name].(map[string]any)
 return prop["type"]=="string"
}
// Preserve integer precision instead of silently rounding tool arguments through float64.
// json.Number is an internal representation, not a promise of Python numeric-type parity.
func decodeToolJSON(text string)(any,error){
 dec:=json.NewDecoder(strings.NewReader(text));dec.UseNumber();var value any
 if err:=dec.Decode(&value);err!=nil{return nil,err};var extra any
 if err:=dec.Decode(&extra);err!=io.EOF{return nil,errors.New("trailing JSON data")};return value,nil
}
// Transcription of the supplied parse_tool_call, including its lenient final-value behavior.
// Stream framing is stricter and does not emit an unfinished call.
func parseToolCall(body string,schema map[string]any) (*Call,error) {
 body=strings.TrimSpace(body);gt:=strings.IndexByte(body,'>')
 if !strings.HasPrefix(body,"<function=")||gt<0{return nil,errors.New("malformed tool call")}
 call:=&Call{Name:strings.TrimSpace(body[len("<function="):gt]),Arguments:map[string]any{}}
 rest:=body[gt+1:]
 for {
  at:=strings.Index(rest,"<parameter=");if at<0{break};rest=rest[at+len("<parameter="):]
  gt=strings.IndexByte(rest,'>');if gt<0{return nil,errors.New("malformed parameter opener")};name:=rest[:gt];rest=rest[gt+1:]
  end:=parameterEnd(rest,true);value:=rest
  if end>=0 {value=rest[:end];rest=rest[end+len("</parameter>"):]} else {rest=""}
  value=strings.TrimSuffix(strings.TrimPrefix(value,"\n"),"\n")
  if declaredString(schema,name) {call.Arguments[name]=value} else {decoded,err:=decodeToolJSON(value);if err!=nil{decoded=value};call.Arguments[name]=decoded}
 }
 return call,nil
}
func parseCall(body string) (*Call,error) {return parseToolCall(body,nil)}
var jsonFence=regexp.MustCompile("(?i)^```[ \\t]*(?:json)?[ \\t]*\\r?\\n\\s*")
// Only a declared tool qualifies. No schema coercion is applied to JSON arguments.
func jsonToolCall(body string,schemas map[string]map[string]any) *Call {
 body=strings.TrimSpace(body)
 if loc:=jsonFence.FindStringIndex(body);loc!=nil {body=strings.TrimRight(body[loc[1]:]," \t\r\n");body=strings.TrimSuffix(body,"```")}
 var obj map[string]json.RawMessage;if json.Unmarshal([]byte(body),&obj)!=nil||obj==nil{return nil}
 var name string;if len(obj["name"])==0||obj["name"][0]!='"'||json.Unmarshal(obj["name"],&name)!=nil{return nil};if _,ok:=schemas[name];!ok{return nil}
 raw,ok:=obj["arguments"];if !ok{raw,ok=obj["parameters"]};if !ok{raw=json.RawMessage(`{}`)}
 var encoded string;if len(raw)>0&&raw[0]=='"' {if json.Unmarshal(raw,&encoded)!=nil{return nil};raw=json.RawMessage(encoded)}
 if strings.TrimSpace(string(raw))=="null"{raw=json.RawMessage(`{}`)}
 decoded,err:=decodeToolJSON(string(raw));if err!=nil{return nil};args,ok:=decoded.(map[string]any);if !ok||args==nil{return nil}
 return &Call{Name:name,Arguments:args}
}
// JSON framing ignores envelope-looking strings inside quoted JSON values.
// Bare/fenced JSON is recognized ONLY inside an explicit <tool_call> envelope.
func jsonObjectEnd(s string) (int,error) {
 if !strings.HasPrefix(s,"{"){return -1,errors.New("expected JSON object")}
 depth:=0;quoted:=false;escape:=false
 for i:=0;i<len(s);i++ {c:=s[i];if quoted {if escape{escape=false}else if c=='\\'{escape=true}else if c=='"'{quoted=false};continue}
  switch c {case '"':quoted=true;case '{','[':depth++;case '}',']':depth--;if depth==0{return i+1,nil}}
 }
 return -1,nil
}
func (p *Parser) framedCall(final bool) (*Call,int,error) {
 trim:=strings.TrimLeft(p.buf," \t\r\n");offset:=len(p.buf)-len(trim)
 if trim==""{return nil,0,nil}
 xml:=strings.HasPrefix(trim,"<function=")
 var body string;end:=0
 if xml {
  end=functionEnd(trim);if end<0{return nil,0,nil};body=trim[:end]
 } else {
  prefix:=0;fenced:=false
  if strings.HasPrefix(trim,"```") {
   loc:=jsonFence.FindStringIndex(trim);if loc==nil {if !strings.Contains(trim,"\n")&&!final{return nil,0,nil};return nil,0,errors.New("invalid JSON fence")};prefix=loc[1];fenced=true
  } else if strings.HasPrefix("```",trim)&&!final{return nil,0,nil}
  object:=trim[prefix:]
  if object==""{return nil,0,nil}
  if !strings.HasPrefix(object,"{") {
   if strings.HasPrefix("<function=",trim)&&!final{return nil,0,nil};return nil,0,errors.New("unsupported tool-call body")
  }
  objectEnd,err:=jsonObjectEnd(object);if err!=nil{return nil,0,err};if objectEnd<0{return nil,0,nil}
  body=object[:objectEnd];end=prefix+objectEnd
  if fenced {
   tail:=trim[end:];after:=strings.TrimLeft(tail," \t\r\n");end+=len(tail)-len(after)
   if !strings.HasPrefix(after,"```"){if strings.HasPrefix("```",after)&&!final{return nil,0,nil};return nil,0,errors.New("missing JSON fence closer")};end+=3
  }
 }
 tail:=trim[end:];after:=strings.TrimLeft(tail," \t\r\n");end+=len(tail)-len(after)
 if !strings.HasPrefix(after,"</tool_call>") {
  if strings.HasPrefix("</tool_call>",after)&&!final{return nil,0,nil};return nil,0,errors.New("missing tool-call closer")
 }
 var call *Call
 if xml {
  gt:=strings.IndexByte(body,'>');name:=strings.TrimSpace(body[len("<function="):gt])
  schema,declared:=p.options.Schemas[name]
  if !declared&&(p.options.DeclaredOnly||len(p.options.Schemas)>0){return nil,0,errors.New("undeclared XML tool")}
  var err error;call,err=parseToolCall(body,schema);if err!=nil{return nil,0,err}
 } else {call=jsonToolCall(body,p.options.Schemas);if call==nil{return nil,0,errors.New("invalid or undeclared JSON tool call")}}
 return call,offset+end+len("</tool_call>"),nil
}
func(p *Parser) Feed(text string,final bool) ([]Event,error) {
 if p.failure!=nil{return nil,p.failure};if p.ended{return nil,errors.New("parser already finalized")}
 fail:=func(out []Event,err error)([]Event,error){p.failure=err;return out,err}
 if len(text)>p.limit-len(p.buf){return fail(nil,errors.New("withheld output exceeds parser limit"))};p.buf+=text;out:=[]Event{}
 for len(p.buf)>0 {
  if p.state=="call" {
   call,consumed,err:=p.framedCall(final);if err!=nil{return fail(out,err)}
   if consumed==0{if final{return fail(out,errors.New("unfinished or malformed tool call"))};break}
   out=append(out,Event{Kind:"tool_call",Call:call});p.buf=p.buf[consumed:];p.state="content";continue
  }
  markers:=[]string{"<tool_call>"};if p.state=="reasoning"{markers=append(markers,"</think>")}
  at:=-1;marker:="";for _,m:=range markers{if i:=strings.Index(p.buf,m);i>=0&&(at<0||i<at){at=i;marker=m}}
  if at>=0 {if at>0{out=append(out,Event{Kind:p.state,Text:p.buf[:at]})};p.buf=p.buf[at+len(marker):];if marker=="</think>"{p.state="content"}else{p.state="call"};continue}
  keep:=0;if !final{for _,m:=range markers{keep=max(keep,suffixPrefix(p.buf,m))}}
  if len(p.buf)>keep{out=append(out,Event{Kind:p.state,Text:p.buf[:len(p.buf)-keep]});p.buf=p.buf[len(p.buf)-keep:]};break
 }
 if final {if p.state=="call"{return fail(out,errors.New("unfinished tool call"))};p.ended=true}
 return out,nil
}

type Detokenizer struct {pending []byte}
func(d *Detokenizer) Feed(b []byte,final bool)(string,error){
 d.pending=append(d.pending,b...);end:=0
 for end<len(d.pending){if !utf8.FullRune(d.pending[end:]){break};r,n:=utf8.DecodeRune(d.pending[end:]);if r==utf8.RuneError&&n==1{return "",errors.New("invalid UTF-8 from engine")};end+=n}
 s:=string(d.pending[:end]);d.pending=append(d.pending[:0],d.pending[end:]...)
 if final&&len(d.pending)>0{return "",fmt.Errorf("incomplete UTF-8: %d bytes",len(d.pending))};return s,nil
}

// BPE merges operate on supplied byte pieces. Family pre-tokenization is NOT implemented.
// ponytail: O(n^2) merge scan for fixtures; use a ranked heap for long production pieces.
func MergeBPE(pieces []string,ranks map[[2]string]int)[]string{
 parts:=append([]string(nil),pieces...)
 for len(parts)>1{best:=-1;rank:=int(^uint(0)>>1);for i:=0;i<len(parts)-1;i++{if r,ok:=ranks[[2]string{parts[i],parts[i+1]}];ok&&r<rank{best=i;rank=r}}
  if best<0{break};parts[best]+=parts[best+1];parts=append(parts[:best+1],parts[best+2:]...)
 };return parts
}

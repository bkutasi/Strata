"""Standalone opt-in exec wrapper, not integrated into upstream launch paths."""
import argparse
import os
from pathlib import Path
import sys


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--server', choices=['python', 'go'], default='python')
    p.add_argument('--go-binary', default=str(Path(__file__).resolve().parent / 'strata-go-experimental'))
    a, rest = p.parse_known_args()
    if a.server == 'python':
        os.execv(sys.executable, [sys.executable, '-m', 'serve.server', *rest])
    binary = Path(a.go_binary).resolve()
    if not binary.is_file() or not os.access(binary, os.X_OK):
        p.error('Go binary is missing or not executable; no silent fallback')
    os.execv(str(binary), [str(binary), *rest])


if __name__ == '__main__':
    main()

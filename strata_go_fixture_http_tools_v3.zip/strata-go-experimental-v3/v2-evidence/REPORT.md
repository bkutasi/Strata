# Strata Go parser/lifecycle increment

Revision: **parser-lifecycle-v2**. Complete source package, not a patch and not a production replacement.

## Correction and baseline

The previous source tree and ZIP were available. The earlier response claiming otherwise was wrong. This iteration continues from that tree; the original tree and ZIP remain untouched. All 16 original Go test entrypoints are retained. The existing FIFO test now waits on state-change notifications rather than polling. The subprocess helper advertises an explicit byte-fixture capability. No test was deleted or skipped.

User-supplied external evidence for **v1 only**, not my execution: Go 1.22.2; race tests, vet, build and fixture HTTP exercise passed; fixture RSS **12,976 KiB** after workload and one second idle. These results do not certify any v2 change, real-model operation, production memory or Strata parity. Attribution and local baseline artifact hash are recorded in `baseline-evidence/user_external_results.json`.

## Implemented in this iteration

- Schema-aware XML arguments: a declared string stays raw, including JSON-looking values. Undeclared types attempt JSON decoding; one leading/trailing newline is removed as in the supplied body. Direct parsing retains the excerpt's lenient unfinished-value behavior; stream framing never emits an unfinished call.
- JSON calls: declared names only, `arguments`/`parameters`, JSON-string arguments, null/default empty objects, optional JSON fences. JSON framing respects strings and escaped quotes, so envelope-looking text inside an argument does not terminate the call.
- XML framing walks parameters. A `</parameter>` followed by ordinary text remains part of the value; only a following parameter/function closer establishes a boundary. Added call-end helper, split-marker withholding, incomplete-input errors, sticky failure/finalization and a buffer bound.
- Tool-choice normalization covers the described OpenAI and Anthropic forms. Required single-tool choices name that tool; multiple tools leave the function name open. Unknown/unsatisfiable choices fall back to no forced opener. These helpers are not connected to HTTP.
- Tool JSON numbers use `json.Number` to avoid silently rounding large integer arguments. This is an internal representation, not Python numeric-type parity.
- Engine bridge now owns each whole GEN/response transaction internally. It rejects non-byte prompt/output IDs and context overflow, preserves EOF/process-exit errors, fails closed on malformed records, and rejects unknown/conflicting finish reasons.
- Cancellation/callback failure sends STOP and drains to DONE before reuse. If STOP is unavailable or draining fails, the bridge closes. A single wait goroutine always reaps the direct child. Concurrent Close wakes readers/waiters, sends QUIT, closes stdin, escalates to kill after the grace period, closes stdout and joins the reader.
- **Safety change:** protocol fixtures must advertise `fixture-byte-v1` in READY. An ordinary native `READY <context> stop` is rejected before GEN. This is a new fixture-only contract, not a native-engine compatibility claim. The bundled fake engine and Go helpers advertise it.
- FIFO Stop now wakes pending requests with an error. State notifications replace the original spin-polling test helper.
- Cancellation fixture tests now hold on an event after the first token, instead of relying on a 10 ms per-token delay. Delay remains available as a workload option, not as test synchronization.

## Source and test coverage

Changed: `parser.go`, `engine.go`, `queue.go`, `main.go` (revision metadata only), `core_test.go`, `fake_engine.py`, `test_fixture.py`, `verify.py`.

Added: `tool_choice.go`, `parser_v2_test.go`, `engine_v2_test.go`, `http_v2_test.go`, `excerpt_oracle.py`, `test_excerpt_oracle.py`, `tool_oracle_cases.json`, compatibility/evidence/feedback files.

Byte-identical to v1: `api.go`, `go.mod`, `launch.py`, `test_launch.py`, `exercise.py`, `mock.json`, `protocol-fixture.json`. Dependencies changed beneath the HTTP code, so this does not prove current HTTP behavior.

There are **46 Go test entrypoints**, including **2 subprocess helpers**, hence 44 substantive test functions. All current Go tests are unrun. New cases cover declared strings, JSON variants, every two-chunk split and byte-by-byte streams for representative XML/JSON/fenced calls, every incomplete prefix of those calls, nested-looking delimiters, choice forms, integer precision, EOF/error/nonfinite records, output limits, cancellation/reuse, concurrent transactions, canceled waiters, concurrent close, idle timeout, forced kill/reap, pipe failures, FIFO order/shutdown and HTTP tool rejection. Timeouts bound failures; no fixed sleeps make Go asynchronous tests pass.

`excerpt_oracle.py` transcribes the two supplied parsing bodies and reconstructs param_end from its description. It generates **37 shared cases** consumed by a Go differential test. The corpus is not a complete upstream oracle, and that Go comparison has not run.

## Commands actually run here

| Command | Result |
|---|---|
| `python3 excerpt_oracle.py` | Passed, generated 37 cases |
| `python3 verify.py` | Python support suite passed: **20 tests in 30.445 s**; overall exit **2** because Go is absent |
| `python3 -m py_compile *.py` | Passed, exit 0 |
| `GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go test -race -count=1 -timeout=120s ./...` | Could not execute, exit 127: `go: command not found` |
| `python3 exercise.py --idle-seconds 1` | Refused absent executable, exit 2; no endpoint or memory result |
| Local source delimiter / baseline-retention / JSON fixture checks | Passed; not compilation or semantic verification |
| Process check | No remaining Python fake-engine process found |

No network access or downloads were attempted in this iteration. The local Go toolchain is still absent. No Go build, vet, race result, current HTTP result or current server memory measurement is claimed. Logs are included; historical evidence is labeled under `baseline-evidence/`.

## Assumptions and remaining gaps

1. The complete param_end, call_end, tool_choice and streaming implementations were not supplied. Their documented cases are implemented, but partial-follower waiting, forced-opener whitespace, finalization errors and strict envelope handling remain assumptions. Bare JSON outside a tool envelope stays ordinary text; no bare-call recovery is claimed.
2. A literal `</parameter>` immediately followed by a syntactically valid next parameter/function closer is inherently ambiguous in this format. The described first-valid-follower rule is used, not a claim of arbitrary nested XML support.
3. JSON numbers are preserved as literals. Python NaN/Infinity extensions, lone-surrogate behavior, all Unicode whitespace differences and Python numeric-type behavior are not equivalent. Go JSON rejects nonstandard NaN/Infinity; XML falls back to raw text for invalid JSON. Schema input is expected to be the normalized template shape. Parser/schema objects are single-owner/immutable during use.
4. Stream calls are emitted whole, not as incremental tool-argument deltas. Quoted/fenced marker disambiguation, tool aliases, recovery, DSML, reasoning budgets, tool IDs and complete streaming parity remain missing.
5. STOP/DONE reuse is established only as a fixture contract. Native command grammar, batching/progress/session/vision variants, restarts and actual model operation remain unavailable. The new fixture capability deliberately rejects an unmodified native engine.
6. Child cleanup is for the direct child only. Owner-FD loss, parent death, process groups/trees, Windows jobs, attestation and owned ready files are missing. Bounded write/stop/kill grace periods do not guarantee recovery from uninterruptible kernel states. Callbacks must return; a permanently blocked callback cannot be preempted safely.
7. HTTP tools remain rejected. Responses, production tokenizer/Jinja templates, vision, MCP, images, sessions, replicas, split serving, operational controls and original run-config semantics are missing. No upstream CLI/desktop/setup/packaging integration is claimed. Browser UI remains excluded.
8. No production memory result exists. The previous 12,976 KiB figure belongs only to the user's v1 fixture run. No GC tuning or constant memory ceiling is claimed.

## Offline build and exercise

From the extracted `strata-go-experimental-v2` directory, with Go 1.22+ and a C compiler already installed for race testing:

```sh
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go vet ./...
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go test -race -count=1 -timeout=120s ./...
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go build -trimpath -o strata-go-experimental .
python3 -m unittest -v test_fixture test_launch test_excerpt_oracle
python3 exercise.py --idle-seconds 1 --output endpoint-memory-v2.json

```

The first three commands cannot download modules or a toolchain. The project has no third-party Go dependencies. `python3 verify.py` is an alternative combined runner; it runs Python tests, gofmt, vet, race tests and build and fails if Go is absent. The endpoint exercise uses an ephemeral loopback port and measures only the Go PID. It still exercises the in-process byte mock, not a real model or the subprocess bridge. The Go subprocess tests exercise the bridge separately.

Manual subprocess-fixture launch, from the extracted directory:

```sh
./strata-go-experimental --config protocol-fixture.json
```

Manual opt-in wrapper launch:

```sh
python3 launch.py --server go --config mock.json
```

Python remains the wrapper default. The wrapper is standalone, not integrated with upstream launch paths.

## Next highest-value increment

First obtain external v2 race/vet/build results. Then complete a fixture-only HTTP tool-call vertical slice: request schemas and tool choice through prompt construction, parser, API-specific streamed/nonstreamed tool serialization and replayed tool results. Keep actual model mode unavailable until vocabulary/pre-tokenization/template bytes can be compared. The current parser increment does not advertise that future HTTP capability.

Use `FEEDBACK.txt` for the next results. Acceptance remains **partial implementation**, not full parity.

# Compatibility matrix: parser-lifecycle-v2

Implemented means source exists, not that it has compiled. Fixture-tested means the named Python fixture/reference was executed. Current Go-tested and parity-verified remain false. User-supplied v1 results are separate evidence.

| Feature | Implemented | Fixture-tested here | Current Go-tested | Parity-verified | Gap / blocker |
|---|---|---|---|---|---|
| XML and JSON tool parser | implemented-source | reference corpus only; Go parser unrun | not-run | not verified | Partial param_end/call_end descriptions; strict stream framing and explicit envelopes are assumptions. |
| Tool-choice helpers | implemented-source | not applicable | not-run | not verified | Forced opener whitespace and malformed-name guard are assumptions. No HTTP tool support. |
| Bridge cancellation, EOF, serialization, reap | implemented-source | Python fake engine passed; Go bridge unrun | not-run | not verified | Byte-fixture handshake required; direct child only; native engine grammar and ownership missing. |
| FIFO shutdown and state notifications | implemented-source | not applicable | not-run | not verified | Go event-driven tests added, unrun. |
| Fixture chat/messages/security/monitoring | retained-source | Python fixture only, not HTTP execution | not-run; previous version user-tested | not verified | HTTP source unchanged; parser and bridge dependencies changed, so previous results do not certify v2. |
| Python fixture and exec launcher | implemented | 15 existing support tests passed | not applicable | not verified against Strata | Python remains default; standalone wrapper only, not upstream integration. |
| Excerpt oracle and corpus | implemented | 5 reference tests passed; 37 corpus cases | Go corpus comparison not-run | not verified against full upstream | Two function bodies transcribed; boundary helper reconstructed from description. |
| Real tokenizer and model templates | missing | not tested | blocked | not verified | No vocabulary, model assets, family pre-tokenization or Jinja implementation. |
| HTTP tools and Responses | missing/unavailable | rejection tests supplied | not-run | not verified | No end-to-end HTTP tool path; Responses returns 501. |
| Vision/MCP/images/sessions/replicas/split | missing | not tested | not-run | not verified | Not implemented. |
| Run configs, manager ownership, desktop/CLI/packaging | missing | standalone wrapper only | not-run | not verified | No upstream integration or native ready/attestation contract. |
| Production 20 MiB memory target | blocked/unmeasured | no current Go PID | not-run | not verified | Previous 12,976 KiB fixture RSS is user-reported for v1 only. |
| Browser UI | excluded | not tested | not-run | not verified | Explicit compatibility difference. |

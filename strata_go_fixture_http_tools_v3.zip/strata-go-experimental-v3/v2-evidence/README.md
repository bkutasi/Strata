# Strata Go experimental: parser-lifecycle-v2

Complete source continuation of the byte-fixture prototype. **Not a production replacement.**

Read `REPORT.md` for changes, assumptions and actual evidence; `COMPATIBILITY.md` / `compatibility.json` distinguish source implementation, Python fixture tests, Go tests and parity. Current Go tests/build/HTTP/memory are unrun here. User-reported v1 results are separately attributed in `baseline-evidence/user_external_results.json`.

## Offline verification

Go 1.22+ and a C compiler must already be installed. No third-party modules are needed.

```sh
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go vet ./...
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go test -race -count=1 -timeout=120s ./...
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go build -trimpath -o strata-go-experimental .
python3 -m unittest -v test_fixture test_launch test_excerpt_oracle
python3 exercise.py --idle-seconds 1 --output endpoint-memory-v2.json

```

Or use `python3 verify.py` for Python tests, gofmt, vet, race tests and build. It sets GOPROXY=off, GOSUMDB=off and GOTOOLCHAIN=local per Go command and returns failure if the compiler is missing.

## Explicit fixture launch

```sh
python3 launch.py --server go --config mock.json
```

The standalone wrapper still defaults to Python and uses exec rather than remaining resident. It is not integrated with upstream Strata. The subprocess mode in `protocol-fixture.json` requires the bundled fake engine's `fixture-byte-v1` READY capability. An ordinary native engine is refused before GEN, because production tokenization and templates are not implemented.

HTTP tools and tool_choice remain rejected. New parser/choice helpers are not an end-to-end HTTP tool implementation. No browser UI is included. No current or production 20 MiB result is claimed.

All source and tests are included. Original evidence is preserved under `baseline-evidence/`; current evidence is `verification.json` and `verification-console.txt`. Copy `FEEDBACK.txt` to report external results.

package main

import (
 "bufio"
 "context"
 "errors"
 "fmt"
 "io"
 "os"
 "os/exec"
 "strconv"
 "strings"
 "sync"
 "time"
)
type Engine interface {
 Generate(context.Context, []int, int, func(int) error) (string,error)
 Close() error
}

// ByteEngine is deliberately a fixture, never a model tokenizer.
type ByteEngine struct { Script string; Delay time.Duration }
func (e *ByteEngine) Generate(ctx context.Context, ids []int, cap int, emit func(int) error) (string,error) {
 if cap<=0||emit==nil{return "",errors.New("invalid generation limit or callback")};if err:=ctx.Err();err!=nil{return "",err}
 b:=[]byte(e.Script); finish:="stop"
 if len(b)>cap { b=b[:cap]; finish="length" }
 for _,t:=range b {
  if e.Delay>0 { timer:=time.NewTimer(e.Delay); select {case <-ctx.Done(): timer.Stop(); return "",ctx.Err(); case <-timer.C:} }
  if err:=ctx.Err(); err!=nil {return "",err}; if err:=emit(int(t)); err!=nil {return "",err}
 }
 return finish,nil
}
func (e *ByteEngine) Close() error {return nil}


type wireLine struct {text string;err error}
var ErrEngineClosed=errors.New("engine is closed")
// One request owns the entire command/response transaction, not just each write.
// This bridge is byte-fixture-only. It cannot safely operate a production model.
type WireEngine struct {
 cmd *exec.Cmd
 in io.WriteCloser
 out *os.File
 lines chan wireLine
 done chan struct{}
 readDone chan struct{}
 waitDone chan struct{}
 gate chan struct{}
 write sync.Mutex
 closeOnce sync.Once
 waitErr error // written once, read only after waitDone closes
 contextSize int
 canStop bool
 timeout time.Duration
}
func startWire(ctx context.Context,argv []string,timeout time.Duration) (*WireEngine,error) {
 if err:=ctx.Err();err!=nil{return nil,err}
 if len(argv)==0||timeout<=0{return nil,errors.New("engine command and positive timeout required")}
 cmd:=exec.Command(argv[0],argv[1:]...);cmd.Stderr=os.Stderr
 in,err:=cmd.StdinPipe();if err!=nil{return nil,err}
 // Own stdout explicitly: cmd.Wait must not close StdoutPipe before buffered output is read.
 out,writer,err:=os.Pipe();if err!=nil{_ = in.Close();return nil,err};cmd.Stdout=writer
 if err=cmd.Start();err!=nil{_ = in.Close();_ = out.Close();_ = writer.Close();return nil,err};_ = writer.Close()
 e:=&WireEngine{cmd:cmd,in:in,out:out,lines:make(chan wireLine,64),done:make(chan struct{}),readDone:make(chan struct{}),waitDone:make(chan struct{}),gate:make(chan struct{},1),timeout:timeout}
 go func(){e.waitErr=cmd.Wait();close(e.waitDone)}() // always reap, even after spontaneous exit
 go func(){
  defer close(e.readDone);defer close(e.lines);defer out.Close()
  scan:=bufio.NewScanner(out);scan.Buffer(make([]byte,4096),1<<20)
  for scan.Scan(){select{case e.lines<-wireLine{text:scan.Text()}:case <-e.done:return}}
  err:=scan.Err();if err==nil{err=io.EOF}
  select{case e.lines<-wireLine{err:err}:case <-e.done:}
 }()
 ready,cancel:=context.WithTimeout(ctx,timeout);defer cancel()
 for {
  line,err:=e.next(ready);if err!=nil{_ = e.Close();return nil,fmt.Errorf("engine readiness: %w",err)}
  if strings.HasPrefix(line,"ERR "){_ = e.Close();return nil,errors.New(line)}
  if strings.HasPrefix(line,"READY") {
   fields:=strings.Fields(line)
   if len(fields)<2||fields[0]!="READY"{_ = e.Close();return nil,errors.New("malformed READY record")}
   n,err:=strconv.Atoi(fields[1]);if err!=nil||n<64||n>1<<20{_ = e.Close();return nil,errors.New("invalid READY context")}
   fixture:=false;e.contextSize=n;for _,f:=range fields[2:]{if f=="stop"{e.canStop=true};if f=="fixture-byte-v1"{fixture=true}}
   if !fixture{_ = e.Close();return nil,errors.New("engine did not advertise fixture-byte-v1; refusing to send byte tokens")};return e,nil
  }
 }
}
func(e *WireEngine) next(ctx context.Context) (string,error) {
 if err:=ctx.Err();err!=nil{return "",err}
 select{case <-ctx.Done():return "",ctx.Err();case <-e.done:return "",ErrEngineClosed;case l,ok:=<-e.lines:if !ok{return "",io.EOF};return l.text,l.err}
}
func(e *WireEngine) send(line string) error {
 e.write.Lock();defer e.write.Unlock()
 pipe,ok:=e.in.(interface{SetWriteDeadline(time.Time)error});if !ok{return errors.New("bounded engine pipe writes unavailable")}
 if err:=pipe.SetWriteDeadline(time.Now().Add(2*time.Second));err!=nil{return err}
 _,err:=io.WriteString(e.in,line+"\n");return err
}
func doneRecord(line string) bool {return line=="DONE"||strings.HasPrefix(line,"DONE ")}
func doneFinish(line string)(string,error){
 if !doneRecord(line){return "",errors.New("not a DONE record")}
 finish:="stop";seen:=false
 for _,field:=range strings.Fields(line)[1:] {
  if strings.HasPrefix(field,"finish="){value:=strings.TrimPrefix(field,"finish=");if value!="stop"&&value!="length"{return "",errors.New("unsupported DONE finish")};if seen&&value!=finish{return "",errors.New("conflicting DONE finish")};finish=value;seen=true
  }else if field=="length"||field=="stop"{if seen&&finish!=field{return "",errors.New("conflicting DONE finish")};finish=field;seen=true}
 };return finish,nil
}
func progressRecord(line string) bool {return strings.HasPrefix(line,"PP ")||strings.HasPrefix(line,"INFO ")||strings.HasPrefix(line,"LP ")}
func byteToken(line string) (int,error) {
 if !strings.HasPrefix(line,"T "){return 0,errors.New("not a token record")}
 id,err:=strconv.Atoi(strings.TrimSpace(line[2:]));if err!=nil||id<0||id>255{return 0,errors.New("invalid byte-fixture engine token")};return id,nil
}
func(e *WireEngine) failed(err error) (string,error) {
 _ = e.Close()
 if errors.Is(err,io.EOF)&&e.waitErr!=nil{return "",errors.Join(err,e.waitErr)}
 return "",err
}
func(e *WireEngine) abort(cause error) (string,error) {
 if !e.canStop{return e.failed(cause)}
 if err:=e.send("STOP");err!=nil{return e.failed(errors.Join(cause,err))}
 drain,cancel:=context.WithTimeout(context.Background(),2*time.Second);defer cancel()
 for {
  line,err:=e.next(drain);if err!=nil{return e.failed(errors.Join(cause,err))}
  if doneRecord(line){if _,err:=doneFinish(line);err!=nil{return e.failed(errors.Join(cause,err))};return "",cause}
  if strings.HasPrefix(line,"T "){if _,err=byteToken(line);err==nil{continue};return e.failed(errors.Join(cause,err))}
  if progressRecord(line){continue}
  return e.failed(errors.Join(cause,fmt.Errorf("invalid cancellation record: %.120s",line)))
 }
}
func(e *WireEngine) Generate(ctx context.Context,ids []int,cap int,emit func(int)error) (string,error) {
 if cap<=0||emit==nil{return "",errors.New("invalid generation limit or callback")}
 if err:=ctx.Err();err!=nil{return "",err}
 select{case <-ctx.Done():return "",ctx.Err();case <-e.done:return "",ErrEngineClosed;case e.gate<-struct{}{}:}
 defer func(){<-e.gate}()
 select{case <-e.done:return "",ErrEngineClosed;default:}
 if err:=ctx.Err();err!=nil{return "",err}
 if cap>e.contextSize-8||len(ids)>e.contextSize-cap-8{return "",errors.New("fixture prompt plus output exceeds context")}
 parts:=make([]string,len(ids));for i,v:=range ids{if v<0||v>255{return "",errors.New("only fixture byte prompt tokens are supported")};parts[i]=strconv.Itoa(v)}
 if err:=e.send(fmt.Sprintf("GEN %d %s",cap,strings.Join(parts,",")));err!=nil{return e.failed(err)}
 count:=0
 for {
  if err:=ctx.Err();err!=nil{return e.abort(err)}
  read,cancel:=context.WithTimeout(ctx,e.timeout);line,err:=e.next(read);cancel()
  if err!=nil{if ctx.Err()!=nil{return e.abort(ctx.Err())};return e.failed(err)}
  if err:=ctx.Err();err!=nil{if doneRecord(line){return "",err};return e.abort(err)}
  select{case <-e.done:return "",ErrEngineClosed;default:}
  if strings.HasPrefix(line,"T ") {
   id,err:=byteToken(line);if err!=nil{return e.failed(err)};count++;if count>cap{return e.failed(errors.New("engine exceeded output limit"))}
   if err=emit(id);err!=nil{return e.abort(err)}
  } else if doneRecord(line) {
   if err:=ctx.Err();err!=nil{return "",err}
   finish,err:=doneFinish(line);if err!=nil{return e.failed(err)};return finish,nil
  } else if strings.HasPrefix(line,"ERR "){return e.failed(errors.New(line))
  } else if !progressRecord(line){return e.failed(fmt.Errorf("unrecognized engine record: %.120s",line))}
 }
}
func(e *WireEngine) Close() error {
 e.closeOnce.Do(func(){
  close(e.done) // immediately wake a blocked reader or generation waiter
  _ = e.send("QUIT");_ = e.in.Close()
  timer:=time.NewTimer(2*time.Second);defer timer.Stop()
  select{case <-e.waitDone:case <-timer.C:_ = e.cmd.Process.Kill();<-e.waitDone}
  _ = e.out.Close();<-e.readDone
 })
 return e.waitErr
}
